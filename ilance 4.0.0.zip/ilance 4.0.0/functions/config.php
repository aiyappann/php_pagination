<?php
error_reporting(0);
/*==========================================================================*\
|| ######################################################################## ||
|| # ILance Marketplace Software 4.0.0 Build 7946
|| # -------------------------------------------------------------------- # ||
|| # Customer License # EopH1ZfJvuKFP7Z
|| # -------------------------------------------------------------------- # ||
|| # Copyright ©2000-2013 ILance Inc. All Rights Reserved.                # ||
|| # This file may not be redistributed in whole or significant part.     # ||
|| # ----------------- ILANCE IS NOT FREE SOFTWARE ---------------------- # ||
|| # http://www.ilance.com | http://www.ilance.com/eula	| info@ilance.com # ||
|| # -------------------------------------------------------------------- # ||
|| ######################################################################## ||
\*==========================================================================*/

define('LICENSEKEY', 'EopH1ZfJvuKFP7Z');
define('HTTP_SERVER', 'http://your-url.com/');
define('HTTPS_SERVER', 'http://your-url.com/');
define('HTTP_SERVER_OTHER', '');
define('HTTPS_SERVER_OTHER', '');
define('DIR_SERVER_ROOT', '/www/htdocs/w011963c/ads/');
define('DIR_SERVER_ROOT_IMAGES', '/www/htdocs/w011963c/ads/');
define('SUB_FOLDER_ROOT', '/');
define('HTTP_CDN_SERVER', '');
define('HTTPS_CDN_SERVER', '');

/**
* Marketplace identifier id
*/
define('SITE_ID', '001');

/**
* Folder name settings
*/
define('DIR_FUNCT_NAME', 'functions');
define('DIR_ADMIN_NAME', 'admincp');
define('DIR_ADMIN_ADDONS_NAME', 'addons');
define('DIR_CORE_NAME', 'core');
define('DIR_CRON_NAME', 'cron');
define('DIR_TMP_NAME', 'cache');
define('DIR_API_NAME', 'api');
define('DIR_XML_NAME', 'xml');
define('DIR_UPLOADS_NAME', 'uploads');
define('DIR_ATTACHMENTS_NAME', 'attachments');
define('DIR_FONTS_NAME', 'fonts');
define('DIR_SOUNDS_NAME', 'sounds');
define('DIR_SWF_NAME', 'swf');
define('DIR_CERTS_NAME', 'certs');
define('DIR_CSS_NAME', 'css');
define('DIR_JS_NAME', 'javascript');
define('DIR_DATASTORE_NAME', 'datastore');

chdir(DIR_SERVER_ROOT . DIR_FUNCT_NAME);
require_once('./global.php');

/*======================================================================*\
|| ####################################################################
|| # Downloaded: Sat, Sep 21st, 2013
|| ####################################################################
\*======================================================================*/
?>