<?php
/*==========================================================================*\
|| ######################################################################## ||
|| # ILance Marketplace Software 4.0.0 Build 7946
|| # -------------------------------------------------------------------- # ||
|| # Customer License # EopH1ZfJvuKFP7Z
|| # -------------------------------------------------------------------- # ||
|| # Copyright ©2000–2013 ILance Inc. All Rights Reserved.                # ||
|| # This file may not be redistributed in whole or significant part.     # ||
|| # ----------------- ILANCE IS NOT FREE SOFTWARE ---------------------- # ||
|| # http://www.ilance.com | http://www.ilance.com/eula	| info@ilance.com # ||
|| # -------------------------------------------------------------------- # ||
|| ######################################################################## ||
\*==========================================================================*/

if (!class_exists('template'))
{
    exit;
}

/**
* Template navigation class responsible for building and constructing the xml navigational menus in iLance
*
* @package      iLance\Template\Nav
* @version      4.0.0.7946
* @author       ILance
*/
class template_nav extends template
{
    /*
    * Function to build and construct the xml navigational menus
    *
    * @param      string      short language identifier (default eng)
    * @param      string      xml nav type (client or admin)
    * @param      string      (custom)
    *
    * @return      
    */
    function construct_nav($slng = 'eng', $navtype = 'client', $customnav = '')
    {
	if (defined('LOCATION') AND LOCATION == 'admin')
	{
	    return;
	}
	global $ilance, $iltemplate, $ilconfig, $ilpage, $show, $topnavlink;
	if (empty($customnav))
	{
	    if ($navtype == 'client')
	    {
		$xml_file = DIR_XML . 'client_leftnav.xml';
	    }
	    else if ($navtype == 'client_topnav')
	    {
		$xml_file = DIR_XML . 'client_topnav.xml';
	    }
	}
	else
	{
	    $xml_file = DIR_XML . $customnav . '.xml';
	}

	$xml = file_get_contents($xml_file);

	($apihook = $ilance->api('construct_nav_xml_start')) ? eval($apihook) : false;

	// #### process our template hooks #############################
	$xml = $this->handle_template_hooks($navtype, $xml);
	$xml_encoding = '';
	if (function_exists('mb_detect_encoding'))
	{
	    $xml_encoding = mb_detect_encoding($xml);
	}

	if ($xml_encoding == 'ASCII')
	{
	    $xml_encoding = '';
	}

	$data = array ();
	$parser = xml_parser_create($xml_encoding);
	xml_parse_into_struct($parser, $xml, $data);
	$error_code = xml_get_error_code($parser);
	xml_parser_free($parser);
	if ($error_code == 0)
	{
	    // #### CLIENT LEFT NAV MENU ###########################
	    if ($navtype == 'client')
	    {
		$result = $this->process_cpnav_xml($data, $xml_encoding, 'CLIENT');
		$navarray = $result['navarray'];

		$css = $html = '';
		$navcount = count($navarray);
		$navcount2 = count($result['navoptions']);
		$totalnavitems = ($navcount + $navcount2);

		for ($i = 0; $i < $navcount; $i++)
		{
		    $rolepassed["$i"] = 1;
		    $subscriptionpassed["$i"] = 1;
		    $modulesoptionpassed["$i"] = 1;

		    // nav header
		    if ($navarray[$i][7] == true)
		    {
			// role permission checkup
			// we will default to all roles enabled unless a role is defined
			// in this case we'll use the rules of the defined role ids.
			if (!empty($navarray["$i"][9]))
			{
			    // roles are being defined for this nav header group
			    // do we have multiple roles to checkup?
			    if (strchr($navarray["$i"][9], ','))
			    {
				// multiple roles detected
				$roles = explode(',', $navarray["$i"][9]);
				if (!empty($_SESSION['ilancedata']['user']['roleid']) AND in_array($_SESSION['ilancedata']['user']['roleid'], $roles))
				{
				    $rolepassed["$i"] = 1;
				}
				else
				{
				    $rolepassed["$i"] = 0;
				    $totalnavitems--;
				}
			    }
			    else
			    {
				// single role detected
				if (!empty($_SESSION['ilancedata']['user']['roleid']) AND $_SESSION['ilancedata']['user']['roleid'] == intval($navarray[$i][9]))
				{
				    $rolepassed["$i"] = 1;
				}
				else
				{
				    $rolepassed["$i"] = 0;
				    $totalnavitems--;
				}
			    }
			}

			// subscription permission checkup
			if (!empty($navarray["$i"][11]))
			{
			    if (empty($_SESSION['ilancedata']['user']['userid']) OR empty($_SESSION['ilancedata']['user']['active']) OR !empty($_SESSION['ilancedata']['user']['active']) AND $_SESSION['ilancedata']['user']['active'] == 'no')
			    {
				$subscriptionpassed["$i"] = 0;
				$totalnavitems--;
			    }
			    else
			    {
				if (strchr($navarray["$i"][11], 'AND'))
				{
				    $subpermission = array_map("trim", explode('AND', $navarray["$i"][11]));
				    foreach ($subpermission as $subperm_key => $subperm_val)
				    {
					$expected = 'no';
					if (substr($subperm_val, 0, 1) == '!')
					{
					    $expected = 'yes';
					    $subperm_val = substr($subperm_val, 1);
					}
					if ($ilance->permissions->check_access($_SESSION['ilancedata']['user']['userid'], $subperm_val) == $expected)
					{
					    $subscriptionpassed["$i"] = 0;
					    $totalnavitems--;
					    break;
					}
				    }
				}
				else if (strchr($navarray["$i"][11], 'OR'))
				{
				    $logic = true;
				    $subpermission = array_map("trim", explode('OR', $navarray["$i"][11]));
				    foreach ($subpermission as $subperm_key => $subperm_val)
				    {
					$expected = 'no';
					if (substr($subperm_val, 0, 1) == '!')
					{
					    $expected = 'yes';
					    $subperm_val = substr($subperm_val, 1);
					}
					if ($ilance->permissions->check_access($_SESSION['ilancedata']['user']['userid'], $subperm_val) != $expected)
					{
					    $logic = false;
					}
				    }
				    if ($logic)
				    {
					$subscriptionpassed["$i"] = 0;
					$totalnavitems--;
				    }
				}
				else
				{
				    if ($ilance->permissions->check_access($_SESSION['ilancedata']['user']['userid'], $navarray["$i"][11]) == 'no')
				    {
					$subscriptionpassed["$i"] = 0;
					$totalnavitems--;
				    }
				}
			    }
			}

			// modules
			$modulesoptionpassed["$i"] = (!empty($navarray["$i"][12])) ? $this->check_modules_opt($navarray["$i"][12]) : true;

			// check for permissions
			// config="" / permission1=""
			if (!empty($navarray["$i"][4]) AND !empty($navarray["$i"][5]))
			{
			    // check permissions
			    if (!empty($ilance->$navarray["$i"][4][$navarray["$i"][5]]) AND $ilance->$navarray["$i"][4][$navarray["$i"][5]])
			    {
				// did the role pass?
				if (!empty($subscriptionpassed["$i"]) AND $subscriptionpassed["$i"] AND !empty($rolepassed["$i"]) AND $rolepassed["$i"] AND !empty($modulesoptionpassed["$i"]) AND $modulesoptionpassed["$i"])
				{
				    $topclass = 'block-content-yellow';
				    $style = 'padding:' . $ilconfig['table_cellpadding'] . 'px; border-right:#ddd solid 1px; border-left:#ddd solid 1px';
				    $navid = $navarray["$i"][8];
				    $link1 = $navarray["$i"][3];
				    $link2 = $navarray["$i"][2];
				    $title = "{" . $navarray[$i][1] . "}";

				    if (!empty($link1))
				    {
					$link = $link1;
				    }
				    else if (!empty($link2))
				    {
					$link = $link2;
				    }
				    else
				    {
					$link = '';
				    }

				    $html1 = $this->fetch_template('leftnav_mycp_navgroup.html');
				    $html1 = $this->parse_hash('leftnav_mycp_navgroup.html', array ('ilpage' => $ilpage), $parseglobals = 0, $html1);
				    $html1 = $this->parse_if_blocks('leftnav_mycp_navgroup.html', $html1, $addslashes = true);

				    $html1 = stripslashes($html1);
				    $html1 = addslashes($html1);

				    eval('$html .= "' . $html1 . '";');

				    $html = stripslashes($html);
				    unset($html1);
				}
			    }
			}
			else
			{
			    // did the role pass?
			    if (!empty($subscriptionpassed["$i"]) AND $subscriptionpassed["$i"] AND !empty($rolepassed["$i"]) AND $rolepassed["$i"] AND !empty($modulesoptionpassed["$i"]) AND $modulesoptionpassed["$i"])
			    {
				$topclass = 'block-content-yellow';
				$style = 'padding:' . $ilconfig['table_cellpadding'] . 'px; border-right:#ddd solid 1px; border-left:#ddd solid 1px';
				$navid = $navarray["$i"][8];
				$link1 = $navarray["$i"][3];
				$link2 = $navarray["$i"][2];
				$title = "{" . $navarray[$i][1] . "}";

				if (!empty($link1))
				{
				    $link = $link1;
				}
				else if (!empty($link2))
				{
				    $link = $link2;
				}
				else
				{
				    $link = '';
				}

				$html1 = $this->fetch_template('leftnav_mycp_navgroup.html');
				$html1 = $this->parse_hash('leftnav_mycp_navgroup.html', array ('ilpage' => $ilpage), $parseglobals = 0, $html1);
				$html1 = $this->parse_if_blocks('leftnav_mycp_navgroup.html', $html1, $addslashes = true);

				$html1 = stripslashes($html1);
				$html1 = addslashes($html1);

				//$html1 = str_replace('$', '\$', $html1);

				eval('$html .= "' . $html1 . '";');

				$html = stripslashes($html);
				unset($html1);
			    }
			}
		    }

		    // leftnav_mycp_navwrapper_start.html
		    $navid = $navarray["$i"][8];

		    $html1 = $this->fetch_template('leftnav_mycp_navwrapper_start.html');
		    $html1 = $this->parse_hash('leftnav_mycp_navwrapper_start.html', array ('ilpage' => $ilpage), $parseglobals = 0, $html1);
		    $html1 = $this->parse_if_blocks('leftnav_mycp_navwrapper_start.html', $html1, $addslashes = true);
		    $html1 = stripslashes($html1);
		    $html1 = addslashes($html1);

		    eval('$html .= "' . $html1 . '";');

		    $html = stripslashes($html);
		    unset($html1);

		    for ($x = 0; $x < $navcount2; $x++)
		    {
			$rolepassed["$x"] = 1;
			$subscriptionpassed["$x"] = 1;
			$modulesoptionpassed["$x"] = 1;

			if ($navarray["$i"][0] == $result['navoptions']["$x"][0])
			{
			    ($apihook = $ilance->api('construct_nav_roles_start')) ? eval($apihook) : false;

			    // role permission checkup
			    // we will default to all roles enabled unless a role is defined
			    // in this case we'll use the rules of the defined role ids.
			    if (!empty($result['navoptions']["$x"][8]))
			    {
				// roles are being defined for this nav header group
				// do we have multiple roles to checkup?
				if (strchr($result['navoptions']["$x"][8], ','))
				{
				    // multiple roles detected
				    $roles = explode(',', $result['navoptions']["$x"][8]);
				    if (!empty($_SESSION['ilancedata']['user']['roleid']) AND in_array($_SESSION['ilancedata']['user']['roleid'], $roles))
				    {
					$rolepassed["$x"] = 1;
				    }
				    else
				    {
					$rolepassed["$x"] = 0;
					$totalnavitems--;
				    }
				}
				else
				{
				    // single role detected
				    if (!empty($_SESSION['ilancedata']['user']['roleid']) AND $_SESSION['ilancedata']['user']['roleid'] == intval($result['navoptions']["$x"][8]))
				    {
					$rolepassed["$x"] = 1;
				    }
				    else
				    {
					$rolepassed["$x"] = 0;
					$totalnavitems--;
				    }
				}
			    }

			    // subscription permission checkup
			    if (!empty($result['navoptions']["$x"][10]))
			    {
				if (empty($_SESSION['ilancedata']['user']['userid']) OR empty($_SESSION['ilancedata']['user']['active']) OR !empty($_SESSION['ilancedata']['user']['active']) AND $_SESSION['ilancedata']['user']['active'] == 'no')
				{
				    $subscriptionpassed["$x"] = 0;
				    $totalnavitems--;
				}
				else
				{
				    if (strchr($result['navoptions']["$x"][10], 'AND'))
				    {
					$subpermission = array_map("trim", explode('AND', $result['navoptions']["$x"][10]));
					foreach ($subpermission as $subperm_key => $subperm_val)
					{
					    $expected = 'no';
					    if (substr($subperm_val, 0, 1) == '!')
					    {
						$expected = 'yes';
						$subperm_val = substr($subperm_val, 1);
					    }
					    if ($ilance->permissions->check_access($_SESSION['ilancedata']['user']['userid'], $subperm_val) == $expected)
					    {
						$subscriptionpassed["$x"] = 0;
						$totalnavitems--;
						break;
					    }
					}
				    }
				    else if (strchr($result['navoptions']["$x"][10], 'OR'))
				    {
					$logic = true;
					$subpermission = array_map("trim", explode('OR', $result['navoptions']["$x"][10]));
					foreach ($subpermission as $subperm_key => $subperm_val)
					{
					    $expected = 'no';
					    if (substr($subperm_val, 0, 1) == '!')
					    {
						$expected = 'yes';
						$subperm_val = substr($subperm_val, 1);
					    }
					    if ($ilance->permissions->check_access($_SESSION['ilancedata']['user']['userid'], $subperm_val) != $expected)
					    {
						$logic = false;
					    }
					}
					if ($logic)
					{
					    $subscriptionpassed["$x"] = 0;
					    $totalnavitems--;
					}
				    }
				    else
				    {
					if ($ilance->permissions->check_access($_SESSION['ilancedata']['user']['userid'], $result['navoptions']["$x"][10]) == 'no')
					{
					    $subscriptionpassed["$x"] = 0;
					    $totalnavitems--;
					}
				    }
				}
			    }

			    // modules
			    $modulesoptionpassed["$x"] = (!empty($navarray["$x"][11])) ? $this->check_modules_opt($navarray["$x"][11]) : true;

			    // check access permissions
			    if (empty($result['navoptions']["$x"][3]))
			    {
				// not using object style config
				// does permission 1 exist?
				$opt1 = $result['navoptions']["$x"][4];
				$opt2 = $result['navoptions']["$x"][5];
				$modulesoptionpasseds["$x"] = (!empty($result['navoptions']["$x"][11])) ? $this->check_modules_opt($result['navoptions']["$x"][11]) : true;

				if (empty($opt1) AND empty($opt2))
				{
				    // no permissions assigned
				    // did the role pass?
				    if (!empty($subscriptionpassed["$x"]) AND $subscriptionpassed["$x"] AND !empty($rolepassed["$x"]) AND $rolepassed["$x"] AND !empty($modulesoptionpassed["$x"]) AND $modulesoptionpassed["$x"])
				    {
					$url = HTTP_SERVER . (($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1]);
					$class = 'alt1 gray';
					$style = 'padding:' . $ilconfig['table_cellpadding'] . 'px; border-right:#ddd solid 1px; border-left:#ddd solid 1px';
					$title = "{" . $result['navoptions']["$x"][7] . "}";
					if (!empty($result['navoptions']["$x"][9]))
					{
					    if (strchr($result['navoptions']["$x"][9], ','))
					    {
						$definestatements = explode(',', $result['navoptions']["$x"][9]);
						if (!empty($topnavlink) AND in_array($topnavlink[0], $definestatements))
						{
						    $class = 'alt1 black';
						    $style = 'font-weight: bold; padding:' . $ilconfig['table_cellpadding'] . 'px; background: white; border: 1px solid #A3A6A9; margin: 0 0 2px -3px; border-right-color: white; border-top-color: white; -webkit-border-radius: 4px 0 0 4px; -webkit-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66); -moz-border-radius: 4px 0 0 4px; -moz-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66);';
						}
					    }
					    else if (!empty($topnavlink) AND in_array($result['navoptions']["$x"][9], $topnavlink))
					    {
						$class = 'alt1 black';
						$style = 'font-weight: bold; padding:' . $ilconfig['table_cellpadding'] . 'px; background: white; border: 1px solid #A3A6A9; margin: 0 0 2px -3px; border-right-color: white; border-top-color: white; -webkit-border-radius: 4px 0 0 4px; -webkit-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66); -moz-border-radius: 4px 0 0 4px; -moz-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66);';
					    }
					}

					$html1 = $this->fetch_template('leftnav_mycp_navoption.html');
					$html1 = $this->parse_hash('leftnav_mycp_navoption.html', array ('ilpage' => $ilpage), $parseglobals = 0, $html1);
					$html1 = $this->parse_if_blocks('leftnav_mycp_navoption.html', $html1, $addslashes = true);

					$html1 = stripslashes($html1);
					$html1 = addslashes($html1);

					eval('$html .= "' . $html1 . '";');

					$html = stripslashes($html);
					unset($html1);
				    }
				}

				if (!empty($opt1) AND !empty($opt2))
				{
				    // permission 1 and 2 both active
				    if (!empty($ilconfig["$opt1"]) AND $ilconfig["$opt1"] AND !empty($ilconfig["$opt2"]) AND $ilconfig["$opt2"])
				    {
					// did the role pass?
					if (!empty($subscriptionpassed["$x"]) AND $subscriptionpassed["$x"] AND !empty($rolepassed["$x"]) AND $rolepassed["$x"] AND !empty($modulesoptionpassed["$x"]) AND $modulesoptionpassed["$x"])
					{
					    $url = HTTP_SERVER . (($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1]);
					    $class = 'alt1 gray';
					    $style = 'padding:' . $ilconfig['table_cellpadding'] . 'px; border-right:#ddd solid 1px; border-left:#ddd solid 1px';
					    $title = "{" . $result['navoptions']["$x"][7] . "}";
					    if (!empty($result['navoptions']["$x"][9]))
					    {
						if (strchr($result['navoptions']["$x"][9], ','))
						{
						    $definestatements = explode(',', $result['navoptions']["$x"][9]);
						    if (!empty($topnavlink) AND in_array($topnavlink[0], $definestatements))
						    {
							$class = 'alt1 black';
							$style = 'font-weight: bold; padding:' . $ilconfig['table_cellpadding'] . 'px; background: white; border: 1px solid #A3A6A9; margin: 0 0 2px -3px; border-right-color: white; border-top-color: white; -webkit-border-radius: 4px 0 0 4px; -webkit-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66); -moz-border-radius: 4px 0 0 4px; -moz-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66);';
						    }
						}
						else if (!empty($topnavlink) AND in_array($result['navoptions']["$x"][9], $topnavlink))
						{
						    $class = 'alt1 black';
						    $style = 'font-weight: bold; padding:' . $ilconfig['table_cellpadding'] . 'px; background: white; border: 1px solid #A3A6A9; margin: 0 0 2px -3px; border-right-color: white; border-top-color: white; -webkit-border-radius: 4px 0 0 4px; -webkit-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66); -moz-border-radius: 4px 0 0 4px; -moz-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66);';
						}
					    }

					    $html1 = $this->fetch_template('leftnav_mycp_navoption.html');
					    $html1 = $this->parse_hash('leftnav_mycp_navoption.html', array ('ilpage' => $ilpage), $parseglobals = 0, $html1);
					    $html1 = $this->parse_if_blocks('leftnav_mycp_navoption.html', $html1, $addslashes = true);

					    $html1 = stripslashes($html1);
					    $html1 = addslashes($html1);

					    eval('$html .= "' . $html1 . '";');

					    $html = stripslashes($html);
					    unset($html1);
					}
				    }
				}

				if (!empty($opt1) AND empty($opt2))
				{
				    // permission 1 active, permission 2 is not
				    if (!empty($ilconfig["$opt1"]) AND $ilconfig["$opt1"])
				    {
					// did the role pass?
					if (!empty($subscriptionpassed["$x"]) AND $subscriptionpassed["$x"] AND !empty($rolepassed["$x"]) AND $rolepassed["$x"] AND !empty($modulesoptionpassed["$x"]) AND $modulesoptionpassed["$x"])
					{
					    $url = HTTP_SERVER . (($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1]);
					    $class = 'alt1 gray';
					    $style = 'padding:' . $ilconfig['table_cellpadding'] . 'px; border-right:#ddd solid 1px; border-left:#ddd solid 1px';
					    $title = "{" . $result['navoptions']["$x"][7] . "}";
					    if (!empty($result['navoptions']["$x"][9]))
					    {
						if (strchr($result['navoptions']["$x"][9], ','))
						{
						    $definestatements = explode(',', $result['navoptions']["$x"][9]);
						    if (!empty($topnavlink) AND in_array($topnavlink[0], $definestatements))
						    {
							$class = 'alt1 black';
							$style = 'font-weight: bold; padding:' . $ilconfig['table_cellpadding'] . 'px; background: white; border: 1px solid #A3A6A9; margin: 0 0 2px -3px; border-right-color: white; border-top-color: white; -webkit-border-radius: 4px 0 0 4px; -webkit-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66); -moz-border-radius: 4px 0 0 4px; -moz-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66);';
						    }
						}
						else if (!empty($topnavlink) AND in_array($result['navoptions']["$x"][9], $topnavlink))
						{
						    $class = 'alt1 black';
						    $style = 'font-weight: bold; padding:' . $ilconfig['table_cellpadding'] . 'px; background: white; border: 1px solid #A3A6A9; margin: 0 0 2px -3px; border-right-color: white; border-top-color: white; -webkit-border-radius: 4px 0 0 4px; -webkit-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66); -moz-border-radius: 4px 0 0 4px; -moz-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66);';
						}
					    }

					    $html1 = $this->fetch_template('leftnav_mycp_navoption.html');
					    $html1 = $this->parse_hash('leftnav_mycp_navoption.html', array ('ilpage' => $ilpage), $parseglobals = 0, $html1);
					    $html1 = $this->parse_if_blocks('leftnav_mycp_navoption.html', $html1, $addslashes = true);

					    $html1 = stripslashes($html1);
					    $html1 = addslashes($html1);

					    eval('$html .= "' . $html1 . '";');

					    $html = stripslashes($html);
					    unset($html1);
					}
				    }
				}

				if (empty($opt1) AND !empty($opt2))
				{
				    // permission 1 is not active, permission 2 is
				    if (!empty($ilconfig["$opt2"]) AND $ilconfig["$opt2"])
				    {
					// did the role pass?
					if (!empty($subscriptionpassed["$x"]) AND $subscriptionpassed["$x"] AND !empty($rolepassed["$x"]) AND $rolepassed["$x"] AND !empty($modulesoptionpassed["$x"]) AND $modulesoptionpassed["$x"])
					{
					    $url = HTTP_SERVER . (($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1]);
					    $class = 'alt1 gray';
					    $style = 'padding:' . $ilconfig['table_cellpadding'] . 'px; border-right:#ddd solid 1px; border-left:#ddd solid 1px';
					    $title = "{" . $result['navoptions']["$x"][7] . "}";
					    if (!empty($result['navoptions']["$x"][9]))
					    {
						if (strchr($result['navoptions']["$x"][9], ','))
						{
						    $definestatements = explode(',', $result['navoptions']["$x"][9]);
						    if (!empty($topnavlink) AND in_array($topnavlink[0], $definestatements))
						    {
							$class = 'alt1 black';
							$style = 'font-weight: bold; padding:' . $ilconfig['table_cellpadding'] . 'px; background: white; border: 1px solid #A3A6A9; margin: 0 0 2px -3px; border-right-color: white; border-top-color: white; -webkit-border-radius: 4px 0 0 4px; -webkit-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66); -moz-border-radius: 4px 0 0 4px; -moz-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66);';
						    }
						}
						else if (!empty($topnavlink) AND in_array($result['navoptions']["$x"][9], $topnavlink))
						{
						    $class = 'alt1 black';
						    $style = 'font-weight: bold; padding:' . $ilconfig['table_cellpadding'] . 'px; background: white; border: 1px solid #A3A6A9; margin: 0 0 2px -3px; border-right-color: white; border-top-color: white; -webkit-border-radius: 4px 0 0 4px; -webkit-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66); -moz-border-radius: 4px 0 0 4px; -moz-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66);';
						}
					    }

					    $html1 = $this->fetch_template('leftnav_mycp_navoption.html');
					    $html1 = $this->parse_hash('leftnav_mycp_navoption.html', array ('ilpage' => $ilpage), $parseglobals = 0, $html1);
					    $html1 = $this->parse_if_blocks('leftnav_mycp_navoption.html', $html1, $addslashes = true);

					    $html1 = stripslashes($html1);
					    $html1 = addslashes($html1);

					    eval('$html .= "' . $html1 . '";');

					    $html = stripslashes($html);
					    unset($html1);
					}
				    }
				}
			    }
			    else
			    {
				// we are using object configuration referencing (lanceads, wantads, stores, etc)
				// do we have both elements?
				$continue = false;
				$continue2 = false;

				$config = $result['navoptions']["$x"][3];
				$pieces = explode('->', $config);
				$opt1 = $result['navoptions']["$x"][4];
				$opt2 = $result['navoptions']["$x"][5];

				if (!empty($opt1) AND !empty($opt2))
				{
				    $continue = false;
				    $continue2 = false;
				    $continue = $ilance->{$pieces[0]}->{$pieces[1]}["$opt1"];
				    //$temp = $ilance->{$pieces[0]}->is_store_owner();
				    $continue2 = $ilance->{$pieces[0]}->{$pieces[1]}["$opt2"];
				}
				else if (empty($opt1) AND !empty($opt2))
				{
				    $continue = true;
				    $continue2 = false;
				    //$temp = $ilance->{$pieces[0]}->is_store_owner();
				    $continue2 = $ilance->{$pieces[0]}->{$pieces[1]}["$opt2"];
				}
				else if (!empty($opt1) AND empty($opt2))
				{
				    $continue = false;
				    $continue2 = true;
				    $continue = isset($ilance->{$pieces[0]}->{$pieces[1]}["$opt1"]) ? $ilance->{$pieces[0]}->{$pieces[1]}["$opt1"] : false;
				}
				else if (empty($opt1) AND empty($opt2))
				{
				    $continue = true;
				    $continue2 = true;
				}
				if ($continue AND $continue2)
				{
				    // did the role pass?
				    if (!empty($subscriptionpassed["$x"]) AND $subscriptionpassed["$x"] AND !empty($rolepassed["$x"]) AND $rolepassed["$x"] AND !empty($modulesoptionpassed["$i"]) AND $modulesoptionpassed["$i"])
				    {
					$url = HTTP_SERVER . (($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1]);
					$class = 'alt1 gray';
					$style = 'padding:' . $ilconfig['table_cellpadding'] . 'px; border-right:#ddd solid 1px; border-left:#ddd solid 1px';
					$title = "{" . $result['navoptions']["$x"][7] . "}";
					if (!empty($result['navoptions']["$x"][9]))
					{
					    if (strchr($result['navoptions']["$x"][9], ','))
					    {
						$definestatements = explode(',', $result['navoptions']["$x"][9]);
						if (!empty($topnavlink) AND in_array($topnavlink[0], $definestatements))
						{
						    $class = 'alt1 black';
						    $style = 'font-weight: bold; padding:' . $ilconfig['table_cellpadding'] . 'px; background: white; border: 1px solid #A3A6A9; margin: 0 0 2px -3px; border-right-color: white; border-top-color: white; -webkit-border-radius: 4px 0 0 4px; -webkit-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66); -moz-border-radius: 4px 0 0 4px; -moz-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66);';
						}
					    }
					    else if (!empty($topnavlink) AND in_array($result['navoptions']["$x"][9], $topnavlink))
					    {
						$class = 'alt1 black';
						$style = 'font-weight: bold; padding:' . $ilconfig['table_cellpadding'] . 'px; background: white; border: 1px solid #A3A6A9; margin: 0 0 2px -3px; border-right-color: white; border-top-color: white; -webkit-border-radius: 4px 0 0 4px; -webkit-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66); -moz-border-radius: 4px 0 0 4px; -moz-box-shadow: -1px 2px 1px rgba(50, 50, 50, .66);';
					    }
					}

					$html1 = $this->fetch_template('leftnav_mycp_navoption.html');
					$html1 = $this->parse_hash('leftnav_mycp_navoption.html', array ('ilpage' => $ilpage), $parseglobals = 0, $html1);
					$html1 = $this->parse_if_blocks('leftnav_mycp_navoption.html', $html1, $addslashes = true);

					$html1 = stripslashes($html1);
					$html1 = addslashes($html1);

					eval('$html .= "' . $html1 . '";');

					$html = stripslashes($html);
					unset($html1);
				    }
				}
			    }
			}
		    }

		    // leftnav_mycp_navwrapper_end.html
		    $html1 = $this->fetch_template('leftnav_mycp_navwrapper_end.html');
		    $html1 = $this->parse_hash('leftnav_mycp_navwrapper_end.html', array ('ilpage' => $ilpage), $parseglobals = 0, $html1);
		    $html1 = $this->parse_if_blocks('leftnav_mycp_navwrapper_end.html', $html1, $addslashes = true);

		    $html1 = stripslashes($html1);
		    $html1 = addslashes($html1);

		    eval('$html .= "' . $html1 . '";');

		    $html = stripslashes($html);
		    unset($html1);
		}

		$navresult = $html;

		$html = '';
		$html = $this->fetch_template('leftnav_mycp.html');
		$html = $this->parse_hash('leftnav_mycp.html', array ('ilpage' => $ilpage), $parseglobals = 0, $html);
		$html = $this->parse_if_blocks('leftnav_mycp.html', $html, $addslashes = true);

		eval('$html = "' . $html . '";');

		// fix for javascript issues like this toggle_tr(\'xxx\') this will make it toggle_tr('xxx') ...
		$html = stripslashes($html);
	    }

	    // #### CLIENT TOP NAV MENU ############################
	    else if ($navtype == 'client_topnav')
	    {
		$result = $this->process_cpnav_xml($data, $xml_encoding, 'CLIENT_TOPNAV');
		$html = '<ul>';
		$navcount = count($result['navoptions']);
		for ($x = 0; $x < $navcount; $x++)
		{
		    // #### $show['xxx'] ###################
		    if (!empty($result['navoptions']["$x"][6]))
		    {
			// do we have multiple $show statements to compare against?
			if (strchr($result['navoptions']["$x"][6], ','))
			{
			    // multiple $show statements detected

			    $showstatements = explode(',', $result['navoptions']["$x"][6]);
			    foreach ($showstatements AS $statement)
			    {
				if (isset($show["$statement"]) AND $show["$statement"])
				{
				    $showpassed["$x"] = true;
				}
				else
				{
				    $showpassed["$x"] = false;
				    break;
				}
			    }
			}
			else
			{
			    // single show detected
			    if (isset($show[$result['navoptions']["$x"][6]]) AND $show[$result['navoptions']["$x"][6]])
			    {
				$showpassed["$x"] = true;
			    }
			    else
			    {
				$showpassed["$x"] = false;
			    }
			}
		    }
		    else
		    {
			$showpassed["$x"] = true;
		    }

		    // #### $ilconfig['xxx'] ###############
		    $configurationpassed["$x"] = (!empty($result['navoptions']["$x"][7])) ? $this->check_ilconfig_opt($result['navoptions']["$x"][7]) : true;

		    // #### SUBSCRIPTION PERMISSIONS ###############
		    if (!empty($result['navoptions']["$x"][10]))
		    {
			if (!empty($_SESSION['ilancedata']['user']['userid']))
			{
			    // do we have multiple permission statements to compare against?
			    if (strchr($result['navoptions']["$x"][10], ','))
			    {
				// multiple permission statements detected
				$permission = explode(',', $result['navoptions']["$x"][10]);
				foreach ($permission AS $statement)
				{
				    if ($ilance->permissions->check_access($_SESSION['ilancedata']['user']['userid'], $statement) == 'yes')
				    {
					$permissionspassed["$x"] = true;
				    }
				    else
				    {
					$permissionspassed["$x"] = false;
					break;
				    }
				}
			    }
			    else
			    {
				// single permission detected
				if ($ilance->permissions->check_access($_SESSION['ilancedata']['user']['userid'], $result['navoptions']["$x"][10]) == 'yes')
				{
				    $permissionspassed["$x"] = true;
				}
				else
				{
				    $permissionspassed["$x"] = false;
				}
			    }
			}
			else
			{
			    $permissionspassed["$x"] = false;
			}
		    }
		    else
		    {
			$permissionspassed["$x"] = true;
		    }

		    // #### MODULES ###############
		    $modulesoptionpassed["$x"] = (!empty($result['navoptions']["$x"][11])) ? $this->check_modules_opt($result['navoptions']["$x"][11]) : true;

		    // #### GUESTS CAN VIEW? ###############
		    if ($result['navoptions']["$x"][3] == 'true' AND $configurationpassed["$x"])
		    {
			$guestscanview["$x"] = true;
		    }
		    else
		    {
			$guestscanview["$x"] = false;
		    }

		    // #### MEMBERS CAN VIEW? ##############
		    if ($result['navoptions']["$x"][4] == 'true' AND $configurationpassed["$x"])
		    {
			$memberscanview["$x"] = true;
		    }
		    else
		    {
			$memberscanview["$x"] = false;
		    }

		    // #### ADMINS CAN VIEW? ###############
		    if ($result['navoptions']["$x"][5] == 'true' AND $configurationpassed["$x"])
		    {
			$adminscanview["$x"] = true;
		    }
		    else
		    {
			$adminscanview["$x"] = false;
		    }

		    // #### WHO ARE WE? ####################
		    $isguest = $ismember = $isadmin = false;

		    if (empty($_SESSION['ilancedata']['user']['userid']) OR $_SESSION['ilancedata']['user']['userid'] == 0)
		    {
			$isguest = true;
		    }
		    if (!empty($_SESSION['ilancedata']['user']['userid']) AND $_SESSION['ilancedata']['user']['userid'] > 0 AND ((isset($_SESSION['ilancedata']['user']['isadmin']) AND $_SESSION['ilancedata']['user']['isadmin'] == '0') OR empty($_SESSION['ilancedata']['user']['isadmin'])))
		    {
			$ismember = true;
		    }
		    if (!empty($_SESSION['ilancedata']['user']['userid']) AND $_SESSION['ilancedata']['user']['userid'] > 0 AND isset($_SESSION['ilancedata']['user']['isadmin']) AND $_SESSION['ilancedata']['user']['isadmin'] == '1')
		    {
			$isadmin = true;
		    }

		    // #### LOCATIONS ######################
		    if (!empty($result['navoptions']["$x"][8]))
		    {
			$passglobalpermissions = ($showpassed["$x"] AND $permissionspassed["$x"] AND $configurationpassed["$x"] AND $modulesoptionpassed["$x"]) ? true : false;
			if (strchr($result['navoptions']["$x"][8], ','))
			{
			    $definestatements = explode(',', $result['navoptions']["$x"][8]);
			    if (!empty($topnavlink) AND in_array($topnavlink[0], $definestatements))
			    {
				if ($isguest)
				{
				    // we are a guest viewing this link
				    if ($guestscanview["$x"])
				    {
					$url = ($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1];
					$urlextra = isset($result['navoptions']["$x"][9]) ? $result['navoptions']["$x"][9] : '';
					$cls = 'current';
					$html .= '<li class="' . $cls . '"><a href="' . HTTP_SERVER . $url . '" ' . $urlextra . '>{' . $result['navoptions']["$x"][0] . '}</a></li>';
				    }
				}
				else if ($ismember AND $passglobalpermissions)
				{
				    // we are a member viewing this link
				    if ($memberscanview["$x"])
				    {
					$url = ($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1];
					$urlextra = isset($result['navoptions']["$x"][9]) ? $result['navoptions']["$x"][9] : '';
					$cls = 'current';
					$html .= '<li class="' . $cls . '"><a href="' . HTTP_SERVER . $url . '" ' . $urlextra . '>{' . $result['navoptions']["$x"][0] . '}</a></li>';
				    }
				}
				else if ($isadmin AND $passglobalpermissions)
				{
				    // we are an admin viewing this link
				    if ($adminscanview["$x"])
				    {
					$url = ($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1];
					$urlextra = isset($result['navoptions']["$x"][9]) ? $result['navoptions']["$x"][9] : '';
					$cls = 'current';
					$html .= '<li class="' . $cls . '"><a href="' . HTTP_SERVER . $url . '" ' . $urlextra . '>{' . $result['navoptions']["$x"][0] . '}</a></li>';
				    }
				}
			    }
			    else
			    {
				if ($isguest)
				{
				    // we are a guest viewing this link
				    if ($guestscanview["$x"])
				    {
					$url = ($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1];
					$urlextra = isset($result['navoptions']["$x"][9]) ? $result['navoptions']["$x"][9] : '';
					$cls = ($x == 0) ? 'first' : '';
					$html .= '<li class="' . $cls . '"><a href="' . HTTP_SERVER . $url . '" ' . $urlextra . '>{' . $result['navoptions']["$x"][0] . '}</a></li>';
				    }
				}
				else if ($ismember AND $passglobalpermissions)
				{
				    // we are a member viewing this link
				    if ($memberscanview["$x"])
				    {
					$url = ($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1];
					$urlextra = isset($result['navoptions']["$x"][9]) ? $result['navoptions']["$x"][9] : '';
					$cls = ($x == 0) ? 'first' : '';
					$html .= '<li class="' . $cls . '"><a href="' . HTTP_SERVER . $url . '" ' . $urlextra . '>{' . $result['navoptions']["$x"][0] . '}</a></li>';
				    }
				}
				else if ($isadmin AND $passglobalpermissions)
				{
				    // we are an admin viewing this link
				    if ($adminscanview["$x"])
				    {
					$url = ($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1];
					$urlextra = isset($result['navoptions']["$x"][9]) ? $result['navoptions']["$x"][9] : '';
					$cls = ($x == 0) ? 'first' : '';
					$html .= '<li class="' . $cls . '"><a href="' . HTTP_SERVER . $url . '" ' . $urlextra . '>{' . $result['navoptions']["$x"][0] . '}</a></li>';
				    }
				}
			    }
			}
			else
			{
			    // single LOCATION detected
			    if (!empty($topnavlink) AND in_array($result['navoptions']["$x"][8], $topnavlink))
			    {
				if ($isguest)
				{
				    // we are a guest viewing this link
				    if ($guestscanview["$x"])
				    {
					$url = ($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1];
					$urlextra = isset($result['navoptions']["$x"][9]) ? $result['navoptions']["$x"][9] : '';
					$cls = 'current';
					$html .= '<li class="' . $cls . '"><a href="' . HTTP_SERVER . $url . '" ' . $urlextra . '>{' . $result['navoptions']["$x"][0] . '}</a></li>';
				    }
				}
				else if ($ismember AND $passglobalpermissions)
				{
				    // we are a member viewing this link
				    if ($memberscanview["$x"])
				    {
					$url = ($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1];
					$urlextra = isset($result['navoptions']["$x"][9]) ? $result['navoptions']["$x"][9] : '';
					$cls = 'current';
					$html .= '<li class="' . $cls . '"><a href="' . HTTP_SERVER . $url . '" ' . $urlextra . '>{' . $result['navoptions']["$x"][0] . '}</a></li>';
				    }
				}
				else if ($isadmin AND $passglobalpermissions)
				{
				    // we are an admin viewing this link
				    if ($adminscanview["$x"])
				    {
					$url = ($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1];
					$urlextra = isset($result['navoptions']["$x"][9]) ? $result['navoptions']["$x"][9] : '';
					$cls = 'current';
					$html .= '<li class="' . $cls . '"><a href="' . HTTP_SERVER . $url . '" ' . $urlextra . '>{' . $result['navoptions']["$x"][0] . '}</a></li>';
				    }
				}
			    }
			    else
			    {
				if ($isguest)
				{
				    // we are a guest viewing this link
				    if ($guestscanview["$x"])
				    {
					$url = ($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1];
					$urlextra = isset($result['navoptions']["$x"][9]) ? $result['navoptions']["$x"][9] : '';
					$cls = ($x == 0) ? 'first' : '';
					$html .= '<li class="' . $cls . '"><a href="' . HTTP_SERVER . $url . '" ' . $urlextra . '>{' . $result['navoptions']["$x"][0] . '}</a></li>';
				    }
				}
				else if ($ismember AND $passglobalpermissions)
				{
				    // we are a member viewing this link
				    if ($memberscanview["$x"])
				    {
					$url = ($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1];
					$urlextra = isset($result['navoptions']["$x"][9]) ? $result['navoptions']["$x"][9] : '';
					$cls = ($x == 0) ? 'first' : '';
					$html .= '<li class="' . $cls . '"><a href="' . HTTP_SERVER . $url . '" ' . $urlextra . '>{' . $result['navoptions']["$x"][0] . '}</a></li>';
				    }
				}
				else if ($isadmin AND $passglobalpermissions)
				{
				    // we are an admin viewing this link
				    if ($adminscanview["$x"])
				    {
					$url = ($ilconfig['globalauctionsettings_seourls'] AND !empty($result['navoptions']["$x"][2])) ? $result['navoptions']["$x"][2] : $result['navoptions']["$x"][1];
					$urlextra = isset($result['navoptions']["$x"][9]) ? $result['navoptions']["$x"][9] : '';
					$cls = ($x == 0) ? 'first' : '';
					$html .= '<li class="' . $cls . '"><a href="' . HTTP_SERVER . $url . '" ' . $urlextra . '>{' . $result['navoptions']["$x"][0] . '}</a></li>';
				    }
				}
			    }
			}
		    }
		}

		($apihook = $ilance->api('template_nav_end')) ? eval($apihook) : false;

		$html .= '</ul>';
	    }
	}
	else
	{
	    die("<strong>Fatal:</strong> There is an error with the formatting of the top client navigation xml file [" . xml_error_string($error_code) . "].  Please fix the problem and retry your action.");
	}

	return $html;
    }

    /*
     * Function to print the left side nav that holds service, product, experts and portfolio category logic
     *
     * @param	string	        nav type (service, product, serviceprovider, portfolio)
     * @param        integer         category id
     * @param        boolean         show sub-cats under main cats? (default true)
     * @param        boolean         show both (service and product) categories under one another?
     * @param        boolean         show category count?
     * @param        boolean         show category filters?
     */

    function print_left_nav($navtype = 'service', $cid = 0, $dosubcats = 1, $displayboth = 0, $showcount = 1, $showfilters = false)
    {
	global $ilconfig, $ilpage, $ilance, $phrase, $show, $categoryfinderhtml, $block, $blockcolor, $legend;

	($apihook = $ilance->api('print_left_nav_start')) ? eval($apihook) : false;

	$html = $categorytitle = $block = '';
	if (isset($displayboth) AND $displayboth)
	{
	    if ($ilconfig['categoryboxorder'])
	    {
		if ($ilconfig['globalauctionsettings_serviceauctionsenabled'])
		{
		    $title = '{_services}';
		    if ($cid > 0)
		    {
			$categorytitle = $ilance->categories->title($_SESSION['ilancedata']['user']['slng'], $cid);
		    }
		    $nav = $ilance->categories_parser->print_subcategory_columns(1, 'service', $dosubcats, $_SESSION['ilancedata']['user']['slng'], $cid, '', $showcount, 0, '', '', 1, '', true, true);
		    $html1 = $this->fetch_template('leftnav_service.html');
		    $html1 = $this->parse_hash('leftnav_service.html', array ('ilpage' => $ilpage), 0, $html1);
		    $html1 = $this->parse_if_blocks('leftnav_service.html', $html1, true);
		    $html1 = stripslashes($html1);
		    $html1 = addslashes($html1);
		    eval('$html .= "' . $html1 . '";');
		    $html = stripslashes($html);
		}
		if ($ilconfig['globalauctionsettings_productauctionsenabled'])
		{
		    $title = '{_items}';
		    if ($cid > 0)
		    {
			$categorytitle = $ilance->categories->title($_SESSION['ilancedata']['user']['slng'], $cid);
		    }
		    $nav = $ilance->categories_parser->print_subcategory_columns(1, 'product', $dosubcats, $_SESSION['ilancedata']['user']['slng'], $cid, '', $showcount, 0, '', '', 1, '', true, true);
		    $html2 = $this->fetch_template('leftnav_product.html');
		    $html2 = $this->parse_hash('leftnav_product.html', array ('ilpage' => $ilpage), 0, $html2);
		    $html2 = $this->parse_if_blocks('leftnav_product.html', $html2, true);
		    $html2 = stripslashes($html2);
		    $html2 = addslashes($html2);
		    eval('$html .= "' . $html2 . '";');
		    $html = stripslashes($html);
		}
	    }
	    else
	    {
		if ($ilconfig['globalauctionsettings_productauctionsenabled'])
		{
		    $title = '{_items}';
		    if ($cid > 0)
		    {
			$categorytitle = $ilance->categories->title($_SESSION['ilancedata']['user']['slng'], $cid);
		    }
		    $nav = $ilance->categories_parser->print_subcategory_columns(1, 'product', $dosubcats, $_SESSION['ilancedata']['user']['slng'], $cid, '', $showcount, 0, '', '', 1, '', true, true);
		    $html2 = $this->fetch_template('leftnav_product.html');
		    $html2 = $this->parse_hash('leftnav_product.html', array ('ilpage' => $ilpage), 0, $html2);
		    $html2 = $this->parse_if_blocks('leftnav_product.html', $html2, true);
		    $html2 = stripslashes($html2);
		    $html2 = addslashes($html2);
		    eval('$html .= "' . $html2 . '";');
		    $html = stripslashes($html);
		}
		if ($ilconfig['globalauctionsettings_serviceauctionsenabled'])
		{
		    $title = '{_services}';
		    if ($cid > 0)
		    {
			$categorytitle = $ilance->categories->title($_SESSION['ilancedata']['user']['slng'], $cid);
		    }
		    $nav = $ilance->categories_parser->print_subcategory_columns(1, 'service', $dosubcats, $_SESSION['ilancedata']['user']['slng'], $cid, '', $showcount, 0, '', '', 1, '', true, true);
		    $html1 = $this->fetch_template('leftnav_service.html');
		    $html1 = $this->parse_hash('leftnav_service.html', array ('ilpage' => $ilpage), 0, $html1);
		    $html1 = $this->parse_if_blocks('leftnav_service.html', $html1, true);
		    $html1 = stripslashes($html1);
		    $html1 = addslashes($html1);
		    eval('$html .= "' . $html1 . '";');
		    $html = stripslashes($html);
		}
	    }
	}
	else
	{
	    $blockcolor = 'yellow';
	    $block = '';
	    if ($navtype == 'service' OR $navtype == 'serviceprovider' OR $navtype == 'portfolio' OR $navtype == 'wantads' OR $navtype == 'stores' OR $navtype == 'storesmain')
	    {
		$nav = $ilance->categories_parser->print_subcategory_columns(1, $navtype, $dosubcats, $_SESSION['ilancedata']['user']['slng'], $cid, '', $showcount, 0, '', '', 1, '', true, true);
		if ($navtype == 'portfolio' OR $navtype == 'wantads' OR $navtype == 'serviceprovider')
		{
		    $blockcolor = 'gray';
		    $block = '3';
		}
		else if ($navtype != 'stores' AND $navtype != 'storesmain')
		{
		    $blockcolor = 'gray';
		    $block = '3';
		}
	    }
	    else
	    {
		$nav = $ilance->categories_parser->print_subcategory_columns(1, $navtype, $dosubcats, $_SESSION['ilancedata']['user']['slng'], $cid, '', $showcount, 0, '', '', 1, '', true, true);
	    }
	    $title = '{_categories}';
	    $categorytitle = '';
	    if ($cid > 0)
	    {
		$categorytitle = $ilance->categories->title($_SESSION['ilancedata']['user']['slng'], $cid);
	    }
	    $html = $this->fetch_template('leftnav_categories.html');
	    $html = $this->parse_hash('leftnav_categories.html', array ('ilpage' => $ilpage), 0, $html);
	    $html = $this->parse_if_blocks('leftnav_categories.html', $html, true);
	    $html = stripslashes($html);
	    $html = addslashes($html);
	    $searchfilters = ($showfilters) ? $this->print_search_nav($navtype, $cid) : '';
	    eval('$html = "' . $html . '";');
	    $html = stripslashes($html);
	}

	($apihook = $ilance->api('print_left_nav_end')) ? eval($apihook) : false;

	return $html;
    }

    /*
     * Function to print the left side search options nav that holds service, product and experts category logic
     *
     * @param	string	        nav type (service, product, serviceprovider, portfolio)
     * @param        integer         category id
     */

    function print_search_nav($navtype = '', $cid = 0)
    {
	global $ilance, $ilpage, $ilconfig, $show;
	$html = '';
	$d = $ilconfig['globalserver_distanceresults'];
	$values = array('' => '-', '5' => '5 '.$d, '10' => '10 '.$d, '20' => '20 '.$d, '50' => '50 '.$d, '100' => '100 '.$d, '250' => '250 '.$d, '500' => '500 '.$d, '1000' => '1000 '.$d, '2000' => '2000 '.$d, '5000' => '5000 '.$d, '10000' => '10000 '.$d);
	$radius = (isset($ilance->GPC['radius']) AND !empty($ilance->GPC['radius'])) ? $ilance->GPC['radius'] : '';
	$vars['radius_pulldown'] = construct_pulldown('radius', 'radius', $values, $radius, 'style="font-family: verdana" title="{_radius}"');
	if ($navtype == 'product')
	{
	    $vars['currency_symbol_left'] = $ilance->currency->currencies[$ilconfig['globalserverlocale_defaultcurrency']]['symbol_left'];
	    $vars['currency_symbol_right'] = $ilance->currency->currencies[$ilconfig['globalserverlocale_defaultcurrency']]['symbol_right'];
	    $html = $this->fetch_template('leftnav_searchoptions_product.html');
	    $html = $this->parse_hash('leftnav_searchoptions_product.html', array ('ilpage' => $ilpage, 'vars' => $vars), $parseglobals = 0, $html);
	    $html = $this->handle_template_hooks('leftnav_searchoptions_product.html', $html);
	    $html = $this->parse_if_blocks('leftnav_searchoptions_product.html', $html, $addslashes = true);
	}
	else if ($navtype == 'service')
	{
	    $html = $this->fetch_template('leftnav_searchoptions_service.html');
	    $html = $this->parse_hash('leftnav_searchoptions_service.html', array ('ilpage' => $ilpage, 'vars' => $vars), $parseglobals = 0, $html);
	    $html = $this->handle_template_hooks('leftnav_searchoptions_service.html', $html);
	    $html = $this->parse_if_blocks('leftnav_searchoptions_service.html', $html, $addslashes = true);
	}
	else if ($navtype == 'serviceprovider')
	{
	    $html = $this->fetch_template('leftnav_searchoptions_experts.html');
	    $html = $this->parse_hash('leftnav_searchoptions_experts.html', array ('ilpage' => $ilpage, 'vars' => $vars), $parseglobals = 0, $html);
	    $html = $this->handle_template_hooks('leftnav_searchoptions_experts.html', $html);
	    $html = $this->parse_if_blocks('leftnav_searchoptions_experts.html', $html, $addslashes = true);
	}
	$html = stripslashes($html);
	return $html;
    }

    /*
     * Function for processing an xml nav menu within ILance
     *
     * @param       array
     * @param       array
     * @param       string       xml nav type to process (ADMIN/CLIENT/CLIENT_TOPNAV)
     */
    function process_cpnav_xml($a, $e, $type = 'CLIENT')
    {
	$lang_code = $current_nav_group = $version = '';
	$navgroupdata = $navoptions = array ();
	$counter = count($a);
	for ($i = 0; $i < $counter; $i++)
	{
	    // #### CLIENT LEFT NAV AND ADMIN TOP NAV ##############
	    if ($type == 'CLIENT' OR $type == 'ADMIN')
	    {
		if ($a[$i]['tag'] == $type . 'NAVGROUPS')
		{
		    if ($a[$i]['type'] == 'complete' OR $a[$i]['type'] == 'open')
		    {
			$lang_code = $a[$i]['attributes']['LANGUAGECODE'];
		    }
		}
		else if ($a[$i]['tag'] == $type . 'NAVGROUP')
		{
		    if ($a[$i]['type'] == 'open' OR $a[$i]['type'] == 'complete')
		    {
			if ($type == 'CLIENT')
			{
			    $current_nav_group = mb_strtolower(str_replace(' ', '_', trim($a[$i]['attributes']['PHRASE'])));

			    $navgroupdata[] = array (
				$current_nav_group, // 0
				trim($a[$i]['attributes']['PHRASE']), // 1
				trim($a[$i]['attributes']['LINK']), // 2
				trim($a[$i]['attributes']['SEOLINK']), // 3
				trim($a[$i]['attributes']['CONFIG']), // 4
				trim($a[$i]['attributes']['PERMISSION1']), // 5
				trim($a[$i]['attributes']['PERMISSION2']), // 6
				trim($a[$i]['attributes']['HEADER']), // 7
				trim($a[$i]['attributes']['SORT']), // 8
				trim($a[$i]['attributes']['ROLES']), // 9
				trim($a[$i]['attributes']['LOCATIONS']), // 10
				trim($a[$i]['attributes']['SUBSCRIPTIONPERMISSION']), // 11
				isset($a[$i]['attributes']['MODULES']) ? trim($a[$i]['attributes']['MODULES']) : '', // can be comma separated
			    );
			}
			else if ($type == 'ADMIN')
			{
			    $current_nav_group = mb_strtolower(str_replace(' ', '_', trim($a[$i]['attributes']['PHRASE'])));

			    $navgroupdata[] = array (
				$current_nav_group, // 0
				trim($a[$i]['attributes']['PHRASE']), // 1
				trim($a[$i]['attributes']['LINK']), // 2
				trim($a[$i]['attributes']['SEOLINK']), // 3
				trim($a[$i]['attributes']['CONFIG']), // 4
				trim($a[$i]['attributes']['PERMISSION1']), // 5
				trim($a[$i]['attributes']['PERMISSION2']), // 6
				trim($a[$i]['attributes']['SORT']), // 7
			    );
			}
		    }
		}
		else if ($a[$i]['tag'] == 'OPTION')
		{
		    if ($a[$i]['type'] == 'open' OR $a[$i]['type'] == 'complete')
		    {
			if ($type == 'CLIENT')
			{
			    $navoptions[] = array (
				$current_nav_group, // 0
				trim($a[$i]['attributes']['LINK']), // 1
				trim($a[$i]['attributes']['SEOLINK']), // 2
				trim($a[$i]['attributes']['CONFIG']), // 3
				trim($a[$i]['attributes']['PERMISSION1']), // 4
				trim($a[$i]['attributes']['PERMISSION2']), // 5
				trim($a[$i]['attributes']['SORT']), // 6
				trim($a[$i]['attributes']['PHRASE']), // 7
				trim($a[$i]['attributes']['ROLES']), // 8
				trim($a[$i]['attributes']['LOCATIONS']), // 9
				trim($a[$i]['attributes']['SUBSCRIPTIONPERMISSION']), // 10
				isset($a[$i]['attributes']['MODULES']) ? trim($a[$i]['attributes']['MODULES']) : '', // can be comma separated
			    );
			}
			else if ($type == 'ADMIN')
			{
			    $navoptions[] = array (
				$current_nav_group, // 0
				trim($a[$i]['attributes']['PHRASE']), // 1
				trim($a[$i]['attributes']['LINK']), // 2
				trim($a[$i]['attributes']['SEOLINK']), // 3
				trim($a[$i]['attributes']['CONFIG']), // 4
				trim($a[$i]['attributes']['PERMISSION1']), // 5
				trim($a[$i]['attributes']['PERMISSION2']), // 6
				trim($a[$i]['attributes']['SORT']), // 7
			    );
			}
		    }
		}
	    }
	    else if ($type == 'CLIENT_TOPNAV')
	    {
		if ($a[$i]['tag'] == 'VERSION')
		{
		    if ($a[$i]['type'] == 'complete' OR $a[$i]['type'] == 'open')
		    {
			$version = $a[$i]['attributes']['VERSION'];
		    }
		}
		else if ($a[$i]['tag'] == 'OPTION')
		{
		    if ($a[$i]['type'] == 'open' OR $a[$i]['type'] == 'complete')
		    {
			$navoptions[] = array (
			    trim($a[$i]['attributes']['PHRASE']), // link phrase
			    trim($a[$i]['attributes']['LINK']), // link url
			    trim($a[$i]['attributes']['SEOLINK']), // seo link url
			    trim($a[$i]['attributes']['GUESTS']), // true/false
			    trim($a[$i]['attributes']['MEMBERS']), // true/false
			    trim($a[$i]['attributes']['ADMINS']), // true/false
			    trim($a[$i]['attributes']['SHOW']), // can be comma separated
			    trim($a[$i]['attributes']['CONFIGURATION']), // can be comma separated
			    trim($a[$i]['attributes']['LOCATIONS']), // can be comma separated
			    trim($a[$i]['attributes']['LINKEXTRA']), // extra <a href xxx > control
			    trim($a[$i]['attributes']['PERMISSIONS']), // can be comma separated
			    isset($a[$i]['attributes']['MODULES']) ? trim($a[$i]['attributes']['MODULES']) : '', // can be comma separated
			);
		    }
		}
	    }
	}
	$result = array (
	    'lang_code' => $lang_code,
	    'navarray' => $navgroupdata,
	    'navoptions' => $navoptions,
	    'version' => $version,
	);
	return $result;
    }

    function check_modules_opt($value)
    {
	global $ilance;
	$result = true;
	$mod = explode('|', $value);
	if (isset($mod[0]) AND !empty($mod[0]) AND isset($mod[1]) AND !empty($mod[1]))
	{
	    if (strchr($mod[1], ','))
	    {
		$modoptions = explode(',', $mod[1]);
		foreach ($modoptions AS $modopt)
		{
		    if (isset($ilance->modules->{$mod[0]}->config[$modopt]) AND $ilance->modules->{$mod[0]}->config[$modopt])
		    {
			$result = true;
		    }
		    else
		    {
			$result = false;
			break;
		    }
		}
	    }
	    else
	    {
		// single modules option detected
		$result = (isset($ilance->modules->{$mod[0]}->config[$mod[1]]) AND $ilance->modules->{$mod[0]}->config[$mod[1]]) ? true : false;
	    }
	}
	return $result;
    }

    function check_ilconfig_opt($value)
    {
	global $ilconfig;
	$result = true;
	// do we have multiple $ilconfig statements to compare against?
	if (strchr($value, ','))
	{
	    // multiple $ilconfig statements detected
	    $ilconfigstatements = explode(',', $value);
	    foreach ($ilconfigstatements AS $statement)
	    {
		if (isset($ilconfig["$statement"]) AND $ilconfig["$statement"])
		{
		    $result = true;
		}
		else
		{
		    $result = false;
		    break;
		}
	    }
	}
	else
	{
	    // single permission detected
	    if (isset($ilconfig[$value]) AND $ilconfig[$value])
	    {
		$result = true;
	    }
	    else
	    {
		$result = false;
	    }
	}

	return $result;
    }

}

/*======================================================================*\
|| ####################################################################
|| # Downloaded: Sat, Sep 21st, 2013
|| ####################################################################
\*======================================================================*/
?>