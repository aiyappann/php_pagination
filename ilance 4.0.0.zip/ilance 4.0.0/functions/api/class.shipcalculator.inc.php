<?php
/*==========================================================================*\
|| ######################################################################## ||
|| # ILance Marketplace Software 4.0.0 Build 7946
|| # -------------------------------------------------------------------- # ||
|| # Customer License # EopH1ZfJvuKFP7Z
|| # -------------------------------------------------------------------- # ||
|| # Copyright ©2000–2013 ILance Inc. All Rights Reserved.                # ||
|| # This file may not be redistributed in whole or significant part.     # ||
|| # ----------------- ILANCE IS NOT FREE SOFTWARE ---------------------- # ||
|| # http://www.ilance.com | http://www.ilance.com/eula	| info@ilance.com # ||
|| # -------------------------------------------------------------------- # ||
|| ######################################################################## ||
\*==========================================================================*/

/**
* Shipping Calculator class to perform the majority of realtime shipping rate calculations in ILance.
*
* @package      iLance
* @version	$Revision: 1.0.0 $
* @author       ILance
*/
class shipcalculator
{
	public $cachedataexpiry = 7;
	public $date_cachedataexpiry;
	
        function __construct()
        {
	    global $ilance;
	    $this->date_cachedataexpiry = $ilance->datetimes->fetch_datetime_from_timestamp(TIMESTAMPNOW - ($this->cachedataexpiry * 24*3600));
        }
        
        function get_rates($weight = '1.0', $destination_zipcode = '', $destination_state = '', $destination_country = 'US', $origin_zipcode = '', $origin_state = '', $origin_country = 'US', $carriers = array(), $shipcode = '03', $length = '12', $width = '12', $height = '12', $pickuptype = '06', $packagingtype = '02', $weightunit = 'LBS', $dimensionunit = 'IN', $sizecode = '')
        {
                $rates = array();
                if (isset($carriers['fedex']) AND $carriers['fedex'] AND $fedex = $this->get_fedex_rates($weight, $destination_zipcode, $destination_state, $destination_country, $origin_zipcode, $origin_state, $origin_country, $shipcode, $length, $width, $height, $pickuptype, $packagingtype, $weightunit, $dimensionunit, $sizecode))
                {
                        $rates = array_merge_recursive($rates, $fedex);
                }
                if (isset($carriers['ups']) AND $carriers['ups'] AND $ups = $this->get_ups_rates($weight, $destination_zipcode, $destination_state, $destination_country, $origin_zipcode, $origin_state, $origin_country, $shipcode, $length, $width, $height, $pickuptype, $packagingtype, $weightunit, $dimensionunit, $sizecode))
                {
                        $rates = array_merge_recursive($rates, $ups);
                }
                if (isset($carriers['usps']) AND $carriers['usps'] AND $usps = $this->get_usps_rates($weight, $destination_zipcode, $destination_state, $destination_country, $origin_zipcode, $origin_state, $origin_country, $shipcode, $length, $width, $height, $pickuptype, $packagingtype, $weightunit, $dimensionunit, $sizecode))
                {
                        $rates = array_merge_recursive($rates, $usps);
                }
                return $rates;
        }
        
        function get_fedex_rates($weight = '1.0', $destination_zipcode = '', $destination_state = '', $destination_country = 'US', $origin_zipcode = '', $origin_state = '', $origin_country = 'US', $shipcode = 'FEDEXGROUND', $length = '12', $width = '12', $height = '12', $pickuptype = 'REGULARPICKUP', $packagingtype = '01', $weightunit = 'LBS', $dimensionunit = 'IN', $sizecode = '')
        {
                global $ilance;
                $services = false;
                $options = array();
                $sql = $ilance->db->query("
                        SELECT shipcode, title
                        FROM " . DB_PREFIX . "shippers
                        WHERE carrier = 'fedex'
                        ORDER BY sort ASC
                ");
                if ($ilance->db->num_rows($sql) > 0)
                {
                        while ($res = $ilance->db->fetch_array($sql, DB_ASSOC))
                        {
                                $options[$res['shipcode']] = $res['title'];
                        }
                }
                $rates = $this->fedex_rateshop($weight, $destination_zipcode, $destination_state, $destination_country, $origin_zipcode, $origin_state, $origin_country, $shipcode, $length, $width, $height, $pickuptype, $packagingtype, $weightunit, $dimensionunit, $sizecode);
                $array = $this->xmlize($rates);
                if (isset($array["FDXRateReply"]["#"]["EstimatedCharges"][0]["#"]["DiscountedCharges"][0]["#"]["NetCharge"][0]["#"]))
                {
                        $parser = $array["FDXRateReply"]["#"]["EstimatedCharges"];
                        for ($i = 0; $i < sizeof($parser); $i++)
                        {
                                if (isset($parser[$i]["#"]["DiscountedCharges"][0]["#"]["NetCharge"][0]["#"]))
                                {
                                        $services["carrier"][$i] = 'fedex';
                                        $services["code"][$i] = '';
                                        $services["name"][$i] = '';
                                        $services["price"][$i] = $parser[$i]["#"]["DiscountedCharges"][0]["#"]["NetCharge"][0]["#"];
                                }
                        }
                }
                else
                {
                        if (isset($array["FDXRateReply"]["#"]["Error"][0]["#"]["Message"][0]["#"]))
                        {
                                $services["errorcode"] = $array["FDXRateReply"]["#"]["Error"][0]["#"]["Code"][0]["#"];
                                $services["errordesc"] = $array["FDXRateReply"]["#"]["Error"][0]["#"]["Message"][0]["#"];
                        }
                }
                return $services;
        }
        
        function get_usps_rates($weight = '1.0', $destination_zipcode = '', $destination_state = '', $destination_country = 'US', $origin_zipcode = '', $origin_state = '', $origin_country = 'US', $shipcode = 'EXPRESS', $length = '12', $width = '12', $height = '12', $pickuptype = '', $packagingtype = '', $weightunit = 'LBS', $dimensionunit = '', $sizecode = 'REGULAR')
        {
                global $ilance;
                $services = false;
                $options = array();
                $sql = $ilance->db->query("
                        SELECT shipcode, title
                        FROM " . DB_PREFIX . "shippers
                        WHERE carrier = 'usps'
                        ORDER BY sort ASC
                ");
                if ($ilance->db->num_rows($sql) > 0)
                {
                        while ($res = $ilance->db->fetch_array($sql, DB_ASSOC))
                        {
                                $options[$res['shipcode']] = $res['title'];
                        }
                }
                $rates = $this->usps_rateshop($weight, $destination_zipcode, $destination_state, $destination_country, $origin_zipcode, $origin_state, $origin_country, $shipcode, $length, $width, $height, $pickuptype, $packagingtype, $weightunit, $dimensionunit, $sizecode);
                $array = $this->xmlize($rates);
                if (isset($array["RateResponse"]["#"]["Package"]))
                {
                        $parser = $array["RateResponse"]["#"]["Package"];
                        for ($i = 0; $i < sizeof($parser); $i++)
                        {
                                if (isset($options[$parser[$i]["#"]["Service"][0]["#"]]))
                                {
                                        $services["carrier"][$i] = 'usps';
                                        $services["code"][$i] = $parser[$i]["#"]["Service"][0]["#"];
                                        $services["name"][$i] = $options[$parser[$i]["#"]["Service"][0]["#"]];
                                        $services["price"][$i] = $parser[$i]["#"]["Postage"][0]["#"];
                                }
                        }
                }
                else
                {
                        if (isset($array["Error"]["#"]["Description"]) AND !empty($array["Error"]["#"]["Description"][0]["#"]))
                        {
                                $services["errorcode"] = $array["Error"]["#"]["Number"][0]["#"];
                                $services["errordesc"] = $array["Error"]["#"]["Description"][0]["#"];
                        }
                }
                return $services;
        }
        
        function get_ups_rates($weight = '1.0', $destination_zipcode = '', $destination_state = '', $destination_country = 'US', $origin_zipcode = '', $origin_state = '', $origin_country = 'US', $shipcode = '03', $length = '12', $width = '12', $height = '12', $pickuptype = '06', $packagingtype = '02', $weightunit = 'LBS', $dimensionunit = 'IN', $sizecode = '')
        {
                global $ilance;
                $services = false;
                $options = array();
                $sql = $ilance->db->query("
                        SELECT shipcode, title
                        FROM " . DB_PREFIX . "shippers
                        WHERE carrier = 'ups'
                        ORDER BY sort ASC
                ");
                if ($ilance->db->num_rows($sql) > 0)
                {
                        while ($res = $ilance->db->fetch_array($sql, DB_ASSOC))
                        {
                                $options[$res['shipcode']] = $res['title'];
                        }
                }
                $rates = $this->ups_rateshop($weight, $destination_zipcode, $destination_state, $destination_country, $origin_zipcode, $origin_state, $origin_country, $shipcode, $length, $width, $height, $pickuptype, $packagingtype, $weightunit, $dimensionunit, $sizecode);
                $array = $this->xmlize($rates);
                if (isset($array["RatingServiceSelectionResponse"]["#"]["Response"][0]["#"]["ResponseStatusCode"][0]["#"]))
                {
                        if ($array["RatingServiceSelectionResponse"]["#"]["Response"][0]["#"]["ResponseStatusCode"][0]["#"] > 0)
                        {
                                $parser = $array["RatingServiceSelectionResponse"]["#"]["RatedShipment"];
                                for ($i = 0; $i < sizeof($parser); $i++)
                                {
                                        if (isset($options[$parser[$i]["#"]["Service"][0]["#"]["Code"][0]["#"]]))
                                        {
                                                $services["carrier"][$i] = 'ups';
                                                $services["code"][$i] = $parser[$i]["#"]["Service"][0]["#"]["Code"][0]["#"];
                                                $services["name"][$i] = $options[$parser[$i]["#"]["Service"][0]["#"]["Code"][0]["#"]];
                                                $services["price"][$i] = $parser[$i]["#"]["TotalCharges"][0]["#"]["MonetaryValue"][0]["#"];
						$services["currency"][$i] = $parser[$i]["#"]["TotalCharges"][0]["#"]["CurrencyCode"][0]["#"];
                                        }
                                }
                        }
                        else
                        {
                                $services["errorcode"] = $array["RatingServiceSelectionResponse"]["#"]["Response"][0]["#"]["Error"][0]["#"]["ErrorCode"][0]["#"];
                                $services["errordesc"] = $array["RatingServiceSelectionResponse"]["#"]["Response"][0]["#"]["Error"][0]["#"]["ErrorDescription"][0]["#"];
                        }
                }
                return $services;
        }
        
        function ups_rateshop($weight = '1.0', $destination_zipcode = '', $destination_state = '', $destination_country = 'US', $origin_zipcode = '', $origin_state = '', $origin_country = 'US', $shipcode = '03', $length = '12', $width = '12', $height = '12', $pickuptype = '06', $packagingtype = '02', $weightunit = 'LBS', $dimensionunit = 'IN', $sizecode = '')
        {
                global $ilance, $ilconfig;
                $weight = ($weight < 1) ? 1.0 : number_format($weight, 1, '.', '');
                $sql = $ilance->db->query("
                        SELECT gatewayresult
                        FROM " . DB_PREFIX . "shipping_rates_cache
                        WHERE carrier = 'ups'
                                AND shipcode = '" . $ilance->db->escape_string($shipcode) . "'
                                AND from_country = '" . $ilance->db->escape_string($origin_country) . "'
				AND from_state = '" . $ilance->db->escape_string($origin_state) . "'
                                AND from_zipcode = '" . $ilance->db->escape_string($origin_zipcode) . "'
                                AND to_country = '" . $ilance->db->escape_string($destination_country) . "'
				AND to_state = '" . $ilance->db->escape_string($destination_state) . "'
                                AND to_zipcode = '" . $ilance->db->escape_string($destination_zipcode) . "'
                                AND weight = '" . $ilance->db->escape_string($weight) . "'
                                AND weightunit = '" . $ilance->db->escape_string($weightunit) . "'
                                AND dimensionunit = '" . $ilance->db->escape_string($dimensionunit) . "'
                                AND length = '" . $ilance->db->escape_string($length) . "'
                                AND width = '" . $ilance->db->escape_string($width) . "'
                                AND height = '" . $ilance->db->escape_string($height) . "'
                                AND pickuptype = '" . $ilance->db->escape_string($pickuptype) . "'
                                AND packagetype = '" . $ilance->db->escape_string($packagingtype) . "'
                                AND size = '" . $ilance->db->escape_string($sizecode) . "'
				AND datetime > '" . $ilance->db->escape_string($this->date_cachedataexpiry) . "'
				
                ");
		//AND gatewayresult NOT LIKE '%<error>%'
                if ($ilance->db->num_rows($sql) == 0)
                {
                        $packagingtype = ($packagingtype <= 0) ? '02' : $packagingtype;
                        $pickuptype = ($pickuptype <= 0) ? '01' : $pickuptype;
                        $request = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>
<AccessRequest xml:lang=\"en-US\">
        <AccessLicenseNumber><![CDATA[" . $ilconfig['ups_access_id'] . "]]></AccessLicenseNumber>
        <UserId><![CDATA[" . $ilconfig['ups_username'] . "]]></UserId>
        <Password><![CDATA[" . $ilconfig['ups_password'] . "]]></Password>
</AccessRequest>
<RatingServiceSelectionRequest xml:lang=\"en-US\">
<Request>
        <TransactionReference>
                <CustomerContext>Rating and Service</CustomerContext>
                <XpciVersion>1.0001</XpciVersion>
        </TransactionReference>
        <RequestAction>Rate</RequestAction>
        <RequestOption>shop</RequestOption>
</Request>
<PickupType>
        <Code><![CDATA[$pickuptype]]></Code>
</PickupType>
<Shipment>
        <Shipper>
                <Address>
                        <CountryCode><![CDATA[$origin_country]]></CountryCode>
                        <PostalCode><![CDATA[$origin_zipcode]]></PostalCode>
                </Address>
        </Shipper>
        <ShipTo>
                <Address>
                        <CountryCode><![CDATA[$destination_country]]></CountryCode>
                        <ResidentialAddress>1</ResidentialAddress>
                        <PostalCode><![CDATA[$destination_zipcode]]></PostalCode>
                </Address>
        </ShipTo>
        <Service>
                <Code><![CDATA[$shipcode]]></Code>
        </Service>
        <Package>
                <OversizePackage>0</OversizePackage>
                <Dimensions>
                        <UnitOfMeasurement>
                                <Code><![CDATA[$dimensionunit]]></Code>
                        </UnitOfMeasurement>
                        <Length><![CDATA[$length]]></Length>
                        <Width><![CDATA[$width]]></Width>
                        <Height><![CDATA[$height]]></Height>
                </Dimensions>
                <PackagingType>
                        <Code><![CDATA[$packagingtype]]></Code>
                        <Description>Package</Description>
                </PackagingType>
                <Description>Rate Shopping</Description>
                <PackageWeight>
                        <UnitOfMeasurement>
                                <Code><![CDATA[$weightunit]]></Code>
                                <Description>Pounds</Description>
                        </UnitOfMeasurement>
                        <Weight><![CDATA[$weight]]></Weight>
                </PackageWeight>
        </Package>
<ShipmentServiceOptions/>
</Shipment>
</RatingServiceSelectionRequest>";
                        $result = $this->connect($ilconfig['ups_server'], $request);
                        
                        // #### save rate for later (up to 1 month) ############
                        $ilance->db->query("
                                INSERT INTO " . DB_PREFIX . "shipping_rates_cache
                                (carrier, shipcode, from_country, from_state, from_zipcode, to_country, to_state, to_zipcode, weight, weightunit, dimensionunit, length, width, height, pickuptype, packagetype, size, datetime, gatewayresult)
                                VALUES(
                                'ups',
                                '" . $ilance->db->escape_string($shipcode) . "',
                                '" . $ilance->db->escape_string($origin_country) . "',
                                '" . $ilance->db->escape_string($origin_state) . "',
                                '" . $ilance->db->escape_string($origin_zipcode) . "',
                                '" . $ilance->db->escape_string($destination_country) . "',
                                '" . $ilance->db->escape_string($destination_state) . "',
                                '" . $ilance->db->escape_string($destination_zipcode) . "',
                                '" . $ilance->db->escape_string($weight) . "',
                                '" . $ilance->db->escape_string($weightunit) . "',
                                '" . $ilance->db->escape_string($dimensionunit) . "',
                                '" . $ilance->db->escape_string($length) . "',
                                '" . $ilance->db->escape_string($width) . "',
                                '" . $ilance->db->escape_string($height) . "',
                                '" . $ilance->db->escape_string($pickuptype) . "',
                                '" . $ilance->db->escape_string($packagingtype) . "',
                                '" . $ilance->db->escape_string($sizecode) . "',
                                '" . DATETIME24H . "',
                                '" . $ilance->db->escape_string($result) . "')
                        ");
                }
                else
                {
                        $ilance->db->query("
                                UPDATE " . DB_PREFIX . "shipping_rates_cache
                                SET traffic = traffic + 1
                                WHERE carrier = 'ups'
                                        AND shipcode = '" . $ilance->db->escape_string($shipcode) . "'
                                        AND from_country = '" . $ilance->db->escape_string($origin_country) . "'
                                        AND from_state = '" . $ilance->db->escape_string($origin_state) . "'
                                        AND from_zipcode = '" . $ilance->db->escape_string($origin_zipcode) . "'
                                        AND to_country = '" . $ilance->db->escape_string($destination_country) . "'
                                        AND to_state = '" . $ilance->db->escape_string($destination_state) . "'
                                        AND to_zipcode = '" . $ilance->db->escape_string($destination_zipcode) . "'
                                        AND weight = '" . $ilance->db->escape_string($weight) . "'
                                        AND weightunit = '" . $ilance->db->escape_string($weightunit) . "'
                                        AND dimensionunit = '" . $ilance->db->escape_string($dimensionunit) . "'
                                        AND length = '" . $ilance->db->escape_string($length) . "'
                                        AND width = '" . $ilance->db->escape_string($width) . "'
                                        AND height = '" . $ilance->db->escape_string($height) . "'
                                        AND pickuptype = '" . $ilance->db->escape_string($pickuptype) . "'
                                        AND packagetype = '" . $ilance->db->escape_string($packagingtype) . "'
                                        AND size = '" . $ilance->db->escape_string($sizecode) . "'
                        ");
                        $res = $ilance->db->fetch_array($sql, DB_ASSOC);
                        $result = $res['gatewayresult'];
                }                
                return $result;
        }
        
        function usps_rateshop($weight = '1.0', $destination_zipcode = '', $destination_state = '', $destination_country = 'US', $origin_zipcode = '', $origin_state = '', $origin_country = 'US', $shipcode = 'EXPRESS', $length = '12', $width = '12', $height = '12', $pickuptype = '', $packagingtype = '', $weightunit = '', $dimensionunit = '', $sizecode = 'REGULAR')
        {
                global $ilance, $ilconfig;
                $weight = ($weight < 1) ? 1.0 : number_format($weight, 1, '.', '');
		
                $sql = $ilance->db->query("
                        SELECT gatewayresult
                        FROM " . DB_PREFIX . "shipping_rates_cache
                        WHERE carrier = 'usps'
                                AND shipcode = '" . $ilance->db->escape_string($shipcode) . "'
                                AND from_country = '" . $ilance->db->escape_string($origin_country) . "'
				AND from_state = '" . $ilance->db->escape_string($origin_state) . "'
                                AND from_zipcode = '" . $ilance->db->escape_string($origin_zipcode) . "'
                                AND to_country = '" . $ilance->db->escape_string($destination_country) . "'
				AND to_state = '" . $ilance->db->escape_string($destination_state) . "'
                                AND to_zipcode = '" . $ilance->db->escape_string($destination_zipcode) . "'
                                AND weight = '" . $ilance->db->escape_string($weight) . "'
                                AND weightunit = '" . $ilance->db->escape_string($weightunit) . "'
                                AND dimensionunit = '" . $ilance->db->escape_string($dimensionunit) . "'
                                AND length = '" . $ilance->db->escape_string($length) . "'
                                AND width = '" . $ilance->db->escape_string($width) . "'
                                AND height = '" . $ilance->db->escape_string($height) . "'
                                AND pickuptype = '" . $ilance->db->escape_string($pickuptype) . "'
                                AND packagetype = '" . $ilance->db->escape_string($packagingtype) . "'
                                AND size = '" . $ilance->db->escape_string($sizecode) . "'
				AND datetime > '" . $ilance->db->escape_string($this->date_cachedataexpiry) . "'
				
                ");
		//AND gatewayresult NOT LIKE '%<error>%'
                if ($ilance->db->num_rows($sql) == 0)
                {
                        $request = 'API=RateV4&XML=<RateV4Request USERID="' . $ilconfig['usps_login'] . '" PASSWORD="' . $ilconfig['usps_password'] . '">';
                        $sql = $ilance->db->query("
                                SELECT shipcode, title
                                FROM " . DB_PREFIX . "shippers
                                WHERE carrier = 'usps'
                                ORDER BY sort ASC
                        ");
                        if ($ilance->db->num_rows($sql) > 0)
                        {
                                $count = 0;
                                while ($res = $ilance->db->fetch_array($sql, DB_ASSOC))
                                {
                                        $container = '';
                                        $request .= '<Package ID="' . $count . '">
        <Service>' . $res['shipcode'] . '</Service>
        <ZipOrigination>' . $origin_zipcode . '</ZipOrigination>
        <ZipDestination>' . $destination_zipcode . '</ZipDestination>
        <Pounds>' . $weight . '</Pounds>
        <Ounces>0</Ounces>
        <Size>' . $sizecode . '</Size>
        <Machinable>' . $this->machinable($res['shipcode']) . '</Machinable>
</Package>';
                                        $count++;
                                }
                        }
                        $request .= '</RateV4Request>';
                        $result = $this->connect($ilconfig['usps_server'], $request);
                        
                        // #### save rate for later (up to 1 month) ############
                        $ilance->db->query("
                                INSERT INTO " . DB_PREFIX . "shipping_rates_cache
                                (carrier, shipcode, from_country, from_state, from_zipcode, to_country, to_state, to_zipcode, weight, weightunit, dimensionunit, length, width, height, pickuptype, packagetype, size, datetime, gatewayresult)
                                VALUES(
                                'usps',
                                '" . $ilance->db->escape_string($shipcode) . "',
                                '" . $ilance->db->escape_string($origin_country) . "',
                                '" . $ilance->db->escape_string($origin_state) . "',
                                '" . $ilance->db->escape_string($origin_zipcode) . "',
                                '" . $ilance->db->escape_string($destination_country) . "',
                                '" . $ilance->db->escape_string($destination_state) . "',
                                '" . $ilance->db->escape_string($destination_zipcode) . "',
                                '" . $ilance->db->escape_string($weight) . "',
                                '" . $ilance->db->escape_string($weightunit) . "',
                                '" . $ilance->db->escape_string($dimensionunit) . "',
                                '" . $ilance->db->escape_string($length) . "',
                                '" . $ilance->db->escape_string($width) . "',
                                '" . $ilance->db->escape_string($height) . "',
                                '" . $ilance->db->escape_string($pickuptype) . "',
                                '" . $ilance->db->escape_string($packagingtype) . "',
                                '" . $ilance->db->escape_string($sizecode) . "',
                                '" . DATETIME24H . "',
                                '" . $ilance->db->escape_string($result) . "')
                        ");
                }
                else
                {
                        $ilance->db->query("
                                UPDATE " . DB_PREFIX . "shipping_rates_cache
                                SET traffic = traffic + 1
                                WHERE carrier = 'usps'
                                        AND shipcode = '" . $ilance->db->escape_string($shipcode) . "'
                                        AND from_country = '" . $ilance->db->escape_string($origin_country) . "'
                                        AND from_state = '" . $ilance->db->escape_string($origin_state) . "'
                                        AND from_zipcode = '" . $ilance->db->escape_string($origin_zipcode) . "'
                                        AND to_country = '" . $ilance->db->escape_string($destination_country) . "'
                                        AND to_state = '" . $ilance->db->escape_string($destination_state) . "'
                                        AND to_zipcode = '" . $ilance->db->escape_string($destination_zipcode) . "'
                                        AND weight = '" . $ilance->db->escape_string($weight) . "'
                                        AND weightunit = '" . $ilance->db->escape_string($weightunit) . "'
                                        AND dimensionunit = '" . $ilance->db->escape_string($dimensionunit) . "'
                                        AND length = '" . $ilance->db->escape_string($length) . "'
                                        AND width = '" . $ilance->db->escape_string($width) . "'
                                        AND height = '" . $ilance->db->escape_string($height) . "'
                                        AND pickuptype = '" . $ilance->db->escape_string($pickuptype) . "'
                                        AND packagetype = '" . $ilance->db->escape_string($packagingtype) . "'
                                        AND size = '" . $ilance->db->escape_string($sizecode) . "'
                        ");
                        $res = $ilance->db->fetch_array($sql, DB_ASSOC);
                        $result = $res['gatewayresult'];
                }
                return $result;
        }
        
        function fedex_rateshop($weight = '1.0', $destination_zipcode = '', $destination_state = '', $destination_country = 'US', $origin_zipcode = '', $origin_state = '', $origin_country = 'US', $shipcode = 'FEDEXGROUND', $length = '12', $width = '12', $height = '12', $pickuptype = 'REGULARPICKUP', $packagingtype = 'YOURPACKAGING', $weightunit = 'LBS', $dimensionunit = 'IN', $sizecode = '')
        {
                global $ilance, $ilconfig;
                $weight = ($weight < 1) ? 1.0 : number_format($weight, 1, '.', '');
                $sql = $ilance->db->query("
                        SELECT gatewayresult
                        FROM " . DB_PREFIX . "shipping_rates_cache
                        WHERE carrier = 'fedex'
                                AND shipcode = '" . $ilance->db->escape_string($shipcode) . "'
                                AND from_country = '" . $ilance->db->escape_string($origin_country) . "'
                                AND from_state = '" . $ilance->db->escape_string($origin_state) . "'
                                AND from_zipcode = '" . $ilance->db->escape_string($origin_zipcode) . "'
                                AND to_country = '" . $ilance->db->escape_string($destination_country) . "'
                                AND to_state = '" . $ilance->db->escape_string($destination_state) . "'
                                AND to_zipcode = '" . $ilance->db->escape_string($destination_zipcode) . "'
                                AND weight = '" . $ilance->db->escape_string($weight) . "'
                                AND weightunit = '" . $ilance->db->escape_string($weightunit) . "'
                                AND dimensionunit = '" . $ilance->db->escape_string($dimensionunit) . "'
                                AND length = '" . $ilance->db->escape_string($length) . "'
                                AND width = '" . $ilance->db->escape_string($width) . "'
                                AND height = '" . $ilance->db->escape_string($height) . "'
                                AND pickuptype = '" . $ilance->db->escape_string($pickuptype) . "'
                                AND packagetype = '" . $ilance->db->escape_string($packagingtype) . "'
                                AND size = '" . $ilance->db->escape_string($sizecode) . "'
				AND datetime > '" . $ilance->db->escape_string($this->date_cachedataexpiry) . "'
                ");
		//AND gatewayresult NOT LIKE '%<error>%'
                if ($ilance->db->num_rows($sql) == 0)
                {
                        $packagingtype = ($packagingtype <= 0) ? 'YOURPACKAGING' : $packagingtype;
                        $pickuptype = ($packagingtype <= 0) ? 'REGULARPICKUP' : $pickuptype;
                        $request = '<?xml version="1.0" encoding="UTF-8" ?>
<FDXRateRequest xmlns:api="http://www.fedex.com/fsmapi" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="FDXRateRequest.xsd">
	<RequestHeader>
		<CustomerTransactionIdentifier>Express Rate</CustomerTransactionIdentifier>
		<AccountNumber>' . $ilconfig['fedex_account'] . '</AccountNumber>
		<MeterNumber>' . $ilconfig['fedex_access_id'] . '</MeterNumber>
		<CarrierCode>' . (in_array($shipcode, array('FEDEXGROUND', 'GROUNDHOMEDELIVERY')) ? 'FDXG' : 'FDXE') . '</CarrierCode>
	</RequestHeader>
	<DropoffType>' . (in_array($shipcode, array('FEDEXGROUND', 'GROUNDHOMEDELIVERY')) ? 'REGULARPICKUP' : $pickuptype) . '</DropoffType>
	<Service>' . $shipcode . '</Service>
	<Packaging>' . (in_array($shipcode, array('FEDEXGROUND', 'GROUNDHOMEDELIVERY')) ? 'YOURPACKAGING' : $packagingtype) . '</Packaging>
	<WeightUnits>' . $weightunit . '</WeightUnits>
	<Weight>' . $weight . '</Weight>
	<OriginAddress>
		<StateOrProvinceCode>' . $origin_state . '</StateOrProvinceCode>
		<PostalCode>' . $origin_zipcode . '</PostalCode>
		<CountryCode>' . $origin_country . '</CountryCode>
	</OriginAddress>
	<DestinationAddress>
		<StateOrProvinceCode>' . $destination_state . '</StateOrProvinceCode>
		<PostalCode>' . $destination_zipcode . '</PostalCode>
		<CountryCode>' . $destination_country . '</CountryCode>
	</DestinationAddress>
	<Payment>
		<PayorType>SENDER</PayorType>
	</Payment>
        <Dimensions>
		<Length>' . $length . '</Length>
                <Width>' . $width . '</Width>
                <Height>' . $height . '</Height>
                <Units>' . $dimensionunit . '</Units>
	</Dimensions>
	<PackageCount>1</PackageCount>
</FDXRateRequest>';
                        $result = $this->connect($ilconfig['fedex_server'], $request);
                        
                        // #### save rate for later (up to 1 month) ############
                        $ilance->db->query("
                                INSERT INTO " . DB_PREFIX . "shipping_rates_cache
                                (carrier, shipcode, from_country, from_state, from_zipcode, to_country, to_state, to_zipcode, weight, weightunit, dimensionunit, length, width, height, pickuptype, packagetype, size, datetime, gatewayresult)
                                VALUES(
                                'fedex',
                                '" . $ilance->db->escape_string($shipcode) . "',
                                '" . $ilance->db->escape_string($origin_country) . "',
                                '" . $ilance->db->escape_string($origin_state) . "',
                                '" . $ilance->db->escape_string($origin_zipcode) . "',
                                '" . $ilance->db->escape_string($destination_country) . "',
                                '" . $ilance->db->escape_string($destination_state) . "',
                                '" . $ilance->db->escape_string($destination_zipcode) . "',
                                '" . $ilance->db->escape_string($weight) . "',
                                '" . $ilance->db->escape_string($weightunit) . "',
                                '" . $ilance->db->escape_string($dimensionunit) . "',
                                '" . $ilance->db->escape_string($length) . "',
                                '" . $ilance->db->escape_string($width) . "',
                                '" . $ilance->db->escape_string($height) . "',
                                '" . $ilance->db->escape_string($pickuptype) . "',
                                '" . $ilance->db->escape_string($packagingtype) . "',
                                '" . $ilance->db->escape_string($sizecode) . "',
                                '" . DATETIME24H . "',
                                '" . $ilance->db->escape_string($result) . "')
                        ");
                }
                else
                {
                        $ilance->db->query("
                                UPDATE " . DB_PREFIX . "shipping_rates_cache
                                SET traffic = traffic + 1
                                WHERE carrier = 'fedex'
                                        AND shipcode = '" . $ilance->db->escape_string($shipcode) . "'
                                        AND from_country = '" . $ilance->db->escape_string($origin_country) . "'
                                        AND from_state = '" . $ilance->db->escape_string($origin_state) . "'
                                        AND from_zipcode = '" . $ilance->db->escape_string($origin_zipcode) . "'
                                        AND to_country = '" . $ilance->db->escape_string($destination_country) . "'
                                        AND to_state = '" . $ilance->db->escape_string($destination_state) . "'
                                        AND to_zipcode = '" . $ilance->db->escape_string($destination_zipcode) . "'
                                        AND weight = '" . $ilance->db->escape_string($weight) . "'
                                        AND weightunit = '" . $ilance->db->escape_string($weightunit) . "'
                                        AND dimensionunit = '" . $ilance->db->escape_string($dimensionunit) . "'
                                        AND length = '" . $ilance->db->escape_string($length) . "'
                                        AND width = '" . $ilance->db->escape_string($width) . "'
                                        AND height = '" . $ilance->db->escape_string($height) . "'
                                        AND pickuptype = '" . $ilance->db->escape_string($pickuptype) . "'
                                        AND packagetype = '" . $ilance->db->escape_string($packagingtype) . "'
                                        AND size = '" . $ilance->db->escape_string($sizecode) . "'
                        ");
                        $res = $ilance->db->fetch_array($sql, DB_ASSOC);
                        $result = $res['gatewayresult'];
                }
                return $result;
        }
        
	function connect($url = '', $data = '')
        {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 60);  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);  
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		if (!empty($data))
                {
			curl_setopt($ch, CURLOPT_POST, 1);  
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}  
		curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
		$contents = curl_exec($ch);
		curl_close($ch);
		return $contents;
	}
        
        function shippinglabel($service = '')
        {
                global $ilance, $show, $ilconfig;
                if ($service == 'ups')
                {
                }
                else if ($service == 'usps')
                {
                        
                }
                else if ($service == 'fedex')
                {
                }
                else
                {
                        ($apihook = $ilance->api('shipcalculator_shippinglabel_else')) ? eval($apihook) : false;
                }
        }
	
        function machinable($service = '')
        {
                if ($service == 'PARCEL')
                {
                        return 'TRUE';
                }
                else
                {
                        return 'FALSE'; 
                }
        }
	
        function pickuptypes($service = '', $fetchdefault = false)
        {
                global $ilance, $show, $ilconfig;
		$types = array();
                if ($service == 'ups')
                {
                        $types = array(
                                '01' => 'Daily Pickup',
                                '03' => 'Customer Counter',
                                '06' => 'One Time Pickup',
                                '07' => 'On Call Air',
                                '11' => 'Suggested Retail Rates',
                                '19' => 'Letter Center',
                                '20' => 'Air Service Center'
                        );
                        if ($fetchdefault)
                        {
                                return '01';
                        }
                }
                else if ($service == 'usps')
                {
                        $types = array(
                                '00' => 'None'
                        );
                        if ($fetchdefault)
                        {
                                return '00';
                        }
                }
                else if ($service == 'fedex')
                {
                        $types = array(
                                'REGULARPICKUP' => 'Regular Pick-up',
                                'REQUESTCOURIER' => 'Request Courier',
                                'DROPBOX' => 'Drop Box',
                                'BUSINESSSERVICE CENTER' => 'Business Service Center',
                                'STATION' => 'Station'
                        );
                        if ($fetchdefault)
                        {
                                return 'REGULARPICKUP';
                        }
                }
                else
                {
                        ($apihook = $ilance->api('shipcalculator_pickuptypes_else')) ? eval($apihook) : false;
                }
                return $types;
        }
        
        function packagetypes($service = '', $shipcode = '', $fetchdefault = false)
        {
                global $ilance, $show, $ilconfig;
		$types = array();
                if ($service == 'ups')
                {
                        $types = array(
                                '01' => 'UPS Letter',
                                '02' => 'Your Packaging',
                                '03' => 'UPS Tube',
                                '04' => 'UPS Pak',
                                '21' => 'UPS Express Box',
                                '2a' => 'UPS Express Box - Small',
                                '2b' => 'UPS Express Box - Medium',
                                '2c' => 'UPS Express Box - Large'
                        );
                        if ($fetchdefault)
                        {
                                return '02';
                        }
                }
                else if ($service == 'usps')
                {
                        $types = array('VARIABLE' => 'None');
                        if ($shipcode == 'EXPRESS' OR $shipcode == 'PRIORITY')
                        {
                                $types = array( // container
                                        'FLAT RATE ENVELOPE' => 'Flat Rate Envelope',
                                        'FLAT RATE BOX' => 'Flat Rate Box'
                                );
                        }
                        if ($fetchdefault)
                        {
                                return 'VARIABLE';
                        }
                }
                else if ($service == 'fedex')
                {
                        $types = array(
                                'YOURPACKAGING' => 'Your Packaging',
                                'FEDEXENVELOPE' => 'FedEx Envelope',
                                'FEDEXPAK' => 'FedEx Pak',
                                'FEDEXBOX' => 'FedEx Box',
                                'FEDEXTUBE' => 'FedEx Tube',
                                'FEDEX10KGBOX' => 'FedEx 10KG Box',
                                'FEDEX25KGBOX' => 'FedEx 25KG Box'
                        );
                        if ($fetchdefault)
                        {
                                return 'YOURPACKAGING';
                        }
                }
                else
                {
                        ($apihook = $ilance->api('shipcalculator_packagetypes_else')) ? eval($apihook) : false;
                }
                return $types;
        }
        
        function weightunits($service = '', $fetchdefault = false)
        {
                global $ilance, $show, $ilconfig;
                $units = array();
                if ($service == 'ups')
                {
                        $units = array(
                                'LBS' => 'Pounds',
                                'KGS' => 'Kilograms'
                        );
                        if ($fetchdefault)
                        {
                                return 'LBS';
                        }
                }
                else if ($service == 'usps')
                {
                        $units = array('' => 'None');
                        if ($fetchdefault)
                        {
                                return '';
                        }
                }
                else if ($service == 'fedex')
                {
                        $units = array(
                                'LBS' => 'Pounds',
                                'KGS' => 'Kilograms'
                        );
                        if ($fetchdefault)
                        {
                                return 'LBS';
                        }
                }
                else
                {
                        ($apihook = $ilance->api('shipcalculator_weightunits_else')) ? eval($apihook) : false;
                }
                return $units;
        }
        
        function dimensionunits($service = '', $fetchdefault = false)
        {
                global $ilance, $show, $ilconfig;
		$units = array();
                if ($service == 'ups')
                {
                        $units = array(
                                'IN' => 'Inches',
                                'CM' => 'Centimeters'
                        );
                        if ($fetchdefault)
                        {
                                return 'IN';
                        }
                }
                else if ($service == 'usps')
                {
                        $units = array('' => 'None');
                        if ($fetchdefault)
                        {
                                return '';
                        }
                }
                else if ($service == 'fedex')
                {
                        $units = array(
                                'IN' => 'Inches',
                                'CM' => 'Centimeters'
                        );
                        if ($fetchdefault)
                        {
                                return 'IN';
                        }
                }
                else
                {
                        ($apihook = $ilance->api('shipcalculator_dimensionunits_else')) ? eval($apihook) : false;
                }
                return $units;
        }
        
        function sizeunits($service = '', $l = 0, $w = 0, $h = 0, $fetchdefault = false)
        {
                global $ilance, $show, $ilconfig;
		$units = array();
                if ($service == 'ups')
                {
                        $units = array('' => 'None');
                        if ($fetchdefault)
                        {
                                return '';
                        }
                }
                else if ($service == 'usps')
                {
                        $units = array(
                                'REGULAR' => 'Regular', // Package dimensions are 12" or less
                                'LARGE' => 'Large' // Any package dimension is larger than 12"
                        );
                        if ($fetchdefault)
                        {
                                if ($l > 12 OR $w > 12 OR $h > 12)
                                {
                                        return 'LARGE';
                                }
                                return 'REGULAR';
                        }
                }
                else if ($service == 'fedex')
                {
                        $units = array('' => 'None');
                        if ($fetchdefault)
                        {
                                return '';
                        }
                }
                else
                {
                        ($apihook = $ilance->api('shipcalculator_sizeunits_else')) ? eval($apihook) : false;
                }
                return $units;
        }
        
        function convert_weight_unit($weight, $old_unit, $new_unit)
        {
		$units['OZ'] = 1;
		$units['LBS'] = 0.0625;
		$units['GRAM'] = 28.3495231;
		$units['KG'] = 0.0283495231;
		if ($old_unit != 'OZ')
                {
                        $weight = $weight / $units[$old_unit];
                }
		$weight = $weight * $units[$new_unit];
		if ($weight < .1)
                {
                        $weight = .1;
                }
		return round($weight, 2);
	}
	
	function convert_dimension_unit($size, $old_unit, $new_unit)
        {
		$units['IN'] = 1;
		$units['CM'] = 2.54;
		$units['FT'] = 0.083333;
		if ($old_unit != 'IN')
                {
                        $size = $size / $units[$old_unit];
                }
		$size = $size * $units[$new_unit];
		if ($size < .1)
                {
                        $size = .1;
                }
		return round($size, 2);
	}
        
        function xml_depth($vals, &$i)
        { 
                $children = array();
                if (isset($vals[$i]['value'])) array_push($children, $vals[$i]['value']); 
                while (++$i < count($vals))
                { 
                        switch ($vals[$i]['type'])
                        { 
                                case 'cdata':
                                        array_push($children, $vals[$i]['value']); 
                                break; 
                                case 'complete': 
                                        $tagname = $vals[$i]['tag'];
                                        if (isset($children["$tagname"]))
                                        {
                                                $size = sizeof($children["$tagname"]);
                                        }
                                        else
                                        {
                                                $size = 0;
                                        }
                                        if (isset($vals[$i]['value']))
                                        {
                                                $children[$tagname][$size]["#"] = $vals[$i]['value'];
                                        }
                                        if(isset($vals[$i]["attributes"]))
                                        {
                                                $children[$tagname][$size]["@"] = $vals[$i]["attributes"];
                                        }
                                break; 
                                case 'open': 
                                        $tagname = $vals[$i]['tag'];
                                        if (isset($children["$tagname"]))
                                        {
                                                $size = sizeof($children["$tagname"]);
                                        }
                                        else
                                        {
                                                $size = 0;
                                        }
                                        if(isset($vals[$i]["attributes"]))
                                        {
                                                $children["$tagname"][$size]["@"] = $vals[$i]["attributes"];
                                                $children["$tagname"][$size]["#"] = $this->xml_depth($vals, $i);
                                        }
                                        else
                                        {
                                                $children["$tagname"][$size]["#"] = $this->xml_depth($vals, $i);
                                        }
                                break; 
                                case 'close':
                                        return $children; 
                                break;
                        }
                } 
                return $children;
        }
        
        function xmlize($data)
        {
                $vals = $index = $array = array();
                $parser = xml_parser_create();
                xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
                xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
                xml_parse_into_struct($parser, $data, $vals, $index);
                xml_parser_free($parser);
                $i = 0; 
                if (isset($vals[$i]['tag']))
                {
                        $tagname = $vals[$i]['tag'];
                        if (isset($vals[$i]["attributes"]))
                        {
                                $array[$tagname]["@"] = $vals[$i]["attributes"];
                        }
                        $array[$tagname]["#"] = $this->xml_depth($vals, $i);
                }
                return $array;
        }
}

/*======================================================================*\
|| ####################################################################
|| # Downloaded: Sat, Sep 21st, 2013
|| ####################################################################
\*======================================================================*/
?>