<?php
/*==========================================================================*\
|| ######################################################################## ||
|| # ILance Marketplace Software 4.0.0 Build 7946
|| # -------------------------------------------------------------------- # ||
|| # Customer License # EopH1ZfJvuKFP7Z
|| # -------------------------------------------------------------------- # ||
|| # Copyright ©2000–2013 ILance Inc. All Rights Reserved.                # ||
|| # This file may not be redistributed in whole or significant part.     # ||
|| # ----------------- ILANCE IS NOT FREE SOFTWARE ---------------------- # ||
|| # http://www.ilance.com | http://www.ilance.com/eula	| info@ilance.com # ||
|| # -------------------------------------------------------------------- # ||
|| ######################################################################## ||
\*==========================================================================*/

/**
* Paypal class to perform the majority of functions including ipn response handling.
*
* @package      iLance\PaymentGateway\GoogleCheckout
* @version      4.0.0.7946
* @author       ILance
*/
class googlecheckout
{
        var $timeout;
        var $error_email;
        var $send_time;
        var $currencies_accepted = array('USD', 'GBP', 'EUR', 'CAD');

        /**
        * Function for printing the payment processor custom generated form via POST method.
        *
        * @param       string        amount to process
        * @param       string        transaction description
        * @param       string        sellers payment email
        * @param       string        master currency
        * @param       string        custom generated payment repsonse arguments to be decrypted by ilance payment processor
        * @param       string        return url
        *
        * @return      string        HTML representation of the form (without the ending </form>)
        */
        function print_payment_form($amount = 0, $description = '',$currency = '', $customencrypted = '')
	{
                global $ilpage, $ilconfig;
                $paye  =    $ilconfig['gc_merchant_id'];
		$address = ($ilconfig['googlecheckout_sandbox']) ? 'https://sandbox.google.com/checkout/api/checkout/v2/checkoutForm/Merchant/' : 'https://checkout.google.com/api/checkout/v2/checkoutForm/Merchant/';
                $html = '<form action="'. $address . $paye . '" id="BB_BuyButtonForm" method="post" name="BB_BuyButtonForm" target="_top">  
<input type="hidden" name="item_name_1" value="'. $description .'"/>
<input type="hidden" name="item_description_1" value="'. $description .'"/>
<input type="hidden" name="item_quantity_1" value="1"/>
<input type="hidden" name="item_price_1" value="'. $amount .'"/>
<input type="hidden" name="item_currency_1" value="USD"/>
<input name="shopping-cart.items.item-1.merchant-item-id" type="hidden" value="'. $customencrypted .'" />
<input type="hidden" name="shopping-cart.items.item-1.merchant-private-item-data"  value="' . $customencrypted . '" />
<input name="_charset_" type="hidden" value="utf-8"/>';
                return $html;   
        }
}

/*======================================================================*\
|| ####################################################################
|| # Downloaded: Wed, May 4th, 2011
|| ####################################################################
\*======================================================================*/
?>