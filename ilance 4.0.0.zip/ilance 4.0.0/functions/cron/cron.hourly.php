<?php
/*==========================================================================*\
|| ######################################################################## ||
|| # ILance Marketplace Software 4.0.0 Build 7946
|| # -------------------------------------------------------------------- # ||
|| # Customer License # EopH1ZfJvuKFP7Z
|| # -------------------------------------------------------------------- # ||
|| # Copyright ©2000–2013 ILance Inc. All Rights Reserved.                # ||
|| # This file may not be redistributed in whole or significant part.     # ||
|| # ----------------- ILANCE IS NOT FREE SOFTWARE ---------------------- # ||
|| # http://www.ilance.com | http://www.ilance.com/eula	| info@ilance.com # ||
|| # -------------------------------------------------------------------- # ||
|| ######################################################################## ||
\*==========================================================================*/

if (!isset($GLOBALS['ilance']->db))
{
        die('<strong>Warning:</strong> This script cannot be loaded indirectly.  Operation aborted.');
}

$ilance->timer->start();
$cronlog = '';

// #### build image color search filters #######################################
$cronlog .= $ilance->colors->build_attachment_colors();

($apihook = $ilance->api('cron_hourly')) ? eval($apihook) : false;

$ilance->timer->stop();
log_cron_action('{_the_hourly_tasks_were_executed} ' . $cronlog, $nextitem, $ilance->timer->get());

/*======================================================================*\
|| ####################################################################
|| # Downloaded: Sat, Sep 21st, 2013
|| ####################################################################
\*======================================================================*/
?>