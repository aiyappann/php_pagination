<?php
/*==========================================================================*\
|| ######################################################################## ||
|| # ILance Marketplace Software 4.0.0 Build 7946
|| # -------------------------------------------------------------------- # ||
|| # Customer License # EopH1ZfJvuKFP7Z
|| # -------------------------------------------------------------------- # ||
|| # Copyright ©2000–2013 ILance Inc. All Rights Reserved.                # ||
|| # This file may not be redistributed in whole or significant part.     # ||
|| # ----------------- ILANCE IS NOT FREE SOFTWARE ---------------------- # ||
|| # http://www.ilance.com | http://www.ilance.com/eula	| info@ilance.com # ||
|| # -------------------------------------------------------------------- # ||
|| ######################################################################## ||
\*==========================================================================*/
if (!isset($GLOBALS['ilance']->db))
{
        die('<strong>Warning:</strong> This script cannot be loaded indirectly.  Operation aborted.');
}
$ilance->timer->start();
global $ilconfig;
$cronlog = '';
if ($ilconfig['globalfilters_bulkupload'])
{
	$cronlog .= $ilance->auction_pictures->process_bulk_upload_photos();
}
$ilance->timer->stop();
log_cron_action('{_the_bulk_upload_photos_tasks_were_successfully_executed} ' . $cronlog, $nextitem, $ilance->timer->get());

/*======================================================================*\
|| ####################################################################
|| # Downloaded: Sat, Sep 21st, 2013
|| ####################################################################
\*======================================================================*/
?>