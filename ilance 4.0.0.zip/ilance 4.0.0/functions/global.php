<?php
/*==========================================================================*\
|| ######################################################################## ||
|| # ILance Marketplace Software 4.0.0 Build 7946
|| # -------------------------------------------------------------------- # ||
|| # Customer License # EopH1ZfJvuKFP7Z
|| # -------------------------------------------------------------------- # ||
|| # Copyright ©2000-2013 ILance Inc. All Rights Reserved.                # ||
|| # This file may not be redistributed in whole or significant part.     # ||
|| # ----------------- ILANCE IS NOT FREE SOFTWARE ---------------------- # ||
|| # http://www.ilance.com | http://www.ilance.com/eula	| info@ilance.com # ||
|| # -------------------------------------------------------------------- # ||
|| ######################################################################## ||
\*==========================================================================*/
define('ILANCEVERSION', '4.0.0'); // this should match installer.php
define('VERSIONSTRING', str_replace('.', '', ILANCEVERSION));
define('SVNVERSION', '7946');
$buildversion = SVNVERSION;

/**
* Define our line-break pattern (Windows: \r\n or Linux: \n)
*/
define('LINEBREAK', "\n"); // or \r\n or \r

/**
* defines if we have multibyte encoding available
*/
define('MULTIBYTE', (extension_loaded('mbstring') AND function_exists('mb_detect_encoding')) ? true : false);

/**
* Initialize our $show array for template conditionals
*/
$show = array();

/**
* Paths
*/
require_once('./paths.php');

/**
* Begin our HTML onload document body placeholder
*/
$onload = '';

/**
* Initialize core functions
*/
require_once(DIR_FUNCTIONS . 'connect.php');
require_once(DIR_CORE . 'functions.php');
require_once(DIR_CORE . 'functions_cookie.php');
require_once(DIR_CORE . 'functions_fetch.php');
require_once(DIR_CORE . 'functions_censor.php');
require_once(DIR_CORE . 'functions_pagnation.php');
require_once(DIR_CORE . 'functions_currency.php');
require_once(DIR_CORE . 'functions_license.php');
require_once(DIR_CORE . 'functions_password.php');
require_once(DIR_CORE . 'functions_seo.php');
require_once(DIR_FUNCTIONS . 'init.php');

/**
* Used only when installing the software.
*/
if (defined('LOCATION') AND LOCATION == 'installer')
{
	// define templates folder based on the style currently selected
	define('DIR_TEMPLATES', DIR_SERVER_ROOT . 'templates/');
	return;
}

/**
* Initialize session datastore
*/
if (!session_id())
{
	session_start();
}
else
{
	die('<strong>Fatal:</strong> iLance application must have ownership of the very first session_start().  A previously created session was detected in <strong>global.php</strong> on line <strong>' . __LINE__ . '</strong>.');
}

/**
* Determine and handle a user selected language or style switch
* This function also sets the default currency for the visitor
*/
$ilance->sessions->handle_language_style_changes();

/**
* This will remember users that have selected to be rememberd
* It basically checks and reads $_COOKIE['userid'], $_COOKIE['username'] and $_COOKIE['password']
* and when found, attempts to auto-login and set proper user sessions
*/
$ilance->sessions->init_remembered_session();

/**
* Initialize locale environment (helpful for languages other than english)
*/
$locale = $ilance->fetch_language_locale($_SESSION['ilancedata']['user']['languageid']);
setlocale(LC_TIME, $locale['locale']);
unset($locale);
$ilconfig['official_time'] = print_date('', '', true, false, $ilconfig['globalserverlocale_sitetimezone']);

/**
* For each cookie identifier in the list, this code will hide those elements
*/
$ilcollapse = array();
if (!empty($_COOKIE[COOKIE_PREFIX . 'collapse']))
{
	$cookiedata = explode('|', $_COOKIE[COOKIE_PREFIX . 'collapse']);
	foreach ($cookiedata AS $cookiekey)
	{
		$ilcollapse["collapseobj_$cookiekey"] = 'display: none;';
		$ilcollapse["collapseimg_$cookiekey"] = '_collapsed';
	}
}

/**
* For each cookie identifier in the list, this code will show those elements
*/
if (!empty($_COOKIE[COOKIE_PREFIX . 'deflate']))
{	
	$cookiedata = explode('|', $_COOKIE[COOKIE_PREFIX . 'deflate']);
	foreach ($cookiedata AS $cookiekey)
	{
		$ilcollapse["collapseobj_$cookiekey"] = 'display: inline;';
		$ilcollapse["collapseimg_$cookiekey"] = '_collapsed';
	}	
}
unset($cookiedata, $cookiekey);

// #### handle updating of the region cookie so we can remember guests for a year
if (isset($ilance->GPC['do']) AND $ilance->GPC['do'] == 'saveregion')
{
	// check if a region along with a country id is selected: example: europe.219
	if (!empty($ilance->GPC['region']) AND strrchr($ilance->GPC['region'], '.'))
	{
		set_cookie('region', handle_input_keywords($ilance->GPC['region']));
	}
	// check if acountry is selected: example: United States
	if (!empty($ilance->GPC['country']))
	{
		set_cookie('country', handle_input_keywords($ilance->GPC['country']));
	}
	// check if user supplied us with a zip code
	if (!empty($ilance->GPC['radiuszip']))
	{
		set_cookie('radiuszip', handle_input_keywords(format_zipcode($ilance->GPC['radiuszip'])), false, true, false, 7);
	}
	if (!empty($ilance->GPC['returnurl']))
	{
		refresh(urldecode($ilance->GPC['returnurl']));
		exit();
	}
}

($apihook = $ilance->api('global_start')) ? eval($apihook) : false;

/**
* Initialize main breadcrumb phrases
*/
$ilcrumbs = $ilance->fetch_breadcrumb_titles();

/**
* Initialize styles and template variables backend
*/
$ilance->styles = construct_object('api.styles');

// this style may require a different template folder for html files
define('DIR_TEMPLATES', DIR_SERVER_ROOT . $ilconfig['template_folder']);
define('DIR_TEMPLATES_ADMIN', DIR_SERVER_ROOT . $ilconfig['template_folder'] . 'admincp/');

$show['product_selling_activity'] = $show['service_selling_activity'] = $show['service_buying_activity'] = $show['product_buying_activity'] = false;
if (isset($_SESSION['ilancedata']['user']['userid']) AND !empty($_SESSION['ilancedata']['user']['userid']))
{
	if ($ilconfig['globalauctionsettings_productauctionsenabled'])
	{
		if ($ilance->permissions->check_access($_SESSION['ilancedata']['user']['userid'], 'createproductauctions') == 'yes')
		{
			$show['product_selling_activity'] = true;
		}
		if ($ilance->permissions->check_access($_SESSION['ilancedata']['user']['userid'], 'productbid') == 'yes' OR $ilance->permissions->check_access($_SESSION['ilancedata']['user']['userid'], 'buynow') == 'yes')
		{
			$show['product_buying_activity'] = true;
		}
	}
	if ($ilconfig['globalauctionsettings_serviceauctionsenabled'])
	{
		if ($ilance->permissions->check_access($_SESSION['ilancedata']['user']['userid'], 'servicebid') == 'yes')
		{
			$show['service_selling_activity'] = true;
		}
		if ($ilance->permissions->check_access($_SESSION['ilancedata']['user']['userid'], 'createserviceauctions') == 'yes')
		{
			$show['service_buying_activity'] = true;
		}
	}
}

/*
* Initialize ip banning backend
*/
$ilance->ipban = construct_object('api.ipban');

/**
* Initialize admin control panel breadcrumb and login info
*/
if (defined('LOCATION') AND LOCATION == 'admin')
{
	include_once(DIR_CORE . 'functions_admincp.php');
	$login_include_admin = admin_login_include();
	$ilanceversion = print_version();
}

/**
* Initialize client breadcrumb and login info
*/
if (defined('LOCATION') AND LOCATION == 'registration')
{
	$login_include = '{_registration}' . '...';
	if (!empty($_SESSION['ilancedata']['user']['builduser']))
	{
		$login_include = $ilance->common->login_include();
	}
}
else
{
	$login_include = $ilance->common->login_include();
}

/**
* Initalize referral system tracker
*/
init_referral_tracker();

/**
* Initalize multibyte character encoding
*/
if (MULTIBYTE)
{
	mb_internal_encoding($ilconfig['template_charset']);
}

($apihook = $ilance->api('global_end')) ? eval($apihook) : false;

header('Content-type: text/html; charset="' . $ilconfig['template_charset'] . '"');  
header("Cache-Control: private");
header("Pragma: private");

/*======================================================================*\
|| ####################################################################
|| # Downloaded: Sat, Sep 21st, 2013
|| ####################################################################
\*======================================================================*/
?>